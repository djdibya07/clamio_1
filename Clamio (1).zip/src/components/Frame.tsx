import { FunctionComponent } from "react";
import styles from "./Frame.module.css";

const Frame: FunctionComponent = () => {
  return (
    <div className={styles.frame}>
      <div className={styles.horizontalLine}>
        <div className={styles.div} />
        <div className={styles.div1} />
        <div className={styles.div2} />
        <div className={styles.div3} />
      </div>
      <div className={styles.bottomText}>
        <div className={styles.div4}>Jan</div>
        <div className={styles.div5}>Feb</div>
        <div className={styles.wrapper}>
          <div className={styles.div6}>Mar</div>
        </div>
        <div className={styles.container}>
          <div className={styles.div7}>Apr</div>
        </div>
        <div className={styles.frameDiv}>
          <div className={styles.div8}>May</div>
        </div>
        <div className={styles.wrapper1}>
          <div className={styles.div9}>Jun</div>
        </div>
        <div className={styles.wrapper2}>
          <div className={styles.div10}>Jul</div>
        </div>
      </div>
      <div className={styles.lineChart01}>
        <img className={styles.frameIcon} alt="" src="/frame1@2x.png" />
        <div className={styles.frame1}>
          <button className={styles.toolTips}>
            <div className={styles.text}>3,256,598</div>
            <div className={styles.c}>⌘C</div>
          </button>
          <div className={styles.chartdotWrapper}>
            <img
              className={styles.chartdotIcon}
              loading="lazy"
              alt=""
              src="/chartdot.svg"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Frame;
