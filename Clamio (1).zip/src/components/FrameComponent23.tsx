import { FunctionComponent, useMemo, type CSSProperties } from "react";
import styles from "./FrameComponent23.module.css";

export type FrameComponent23Type = {
  /** Style props */
  propFlex?: CSSProperties["flex"];
  propWidth?: CSSProperties["width"];
  propAlignSelf?: CSSProperties["alignSelf"];
  propFlex1?: CSSProperties["flex"];
  propPadding?: CSSProperties["padding"];
  propHeight?: CSSProperties["height"];
  propPosition?: CSSProperties["position"];
  propHeight1?: CSSProperties["height"];
  propAlignSelf1?: CSSProperties["alignSelf"];
  propPosition1?: CSSProperties["position"];
  propMargin?: CSSProperties["margin"];
  propTop?: CSSProperties["top"];
  propRight?: CSSProperties["right"];
};

const FrameComponent23: FunctionComponent<FrameComponent23Type> = ({
  propFlex,
  propWidth,
  propAlignSelf,
  propFlex1,
  propPadding,
  propHeight,
  propPosition,
  propHeight1,
  propAlignSelf1,
  propPosition1,
  propMargin,
  propTop,
  propRight,
}) => {
  const frameDiv5Style: CSSProperties = useMemo(() => {
    return {
      flex: propFlex,
      width: propWidth,
      alignSelf: propAlignSelf,
    };
  }, [propFlex, propWidth, propAlignSelf]);

  const frameDiv6Style: CSSProperties = useMemo(() => {
    return {
      flex: propFlex1,
      padding: propPadding,
      height: propHeight,
      position: propPosition,
    };
  }, [propFlex1, propPadding, propHeight, propPosition]);

  const rectangleDivStyle: CSSProperties = useMemo(() => {
    return {
      height: propHeight1,
      alignSelf: propAlignSelf1,
    };
  }, [propHeight1, propAlignSelf1]);

  const frameIconStyle: CSSProperties = useMemo(() => {
    return {
      position: propPosition1,
      margin: propMargin,
      top: propTop,
      right: propRight,
    };
  }, [propPosition1, propMargin, propTop, propRight]);

  return (
    <div className={styles.frameParent} style={frameDiv5Style}>
      <div className={styles.rectangleParent} style={frameDiv6Style}>
        <div className={styles.frameChild} style={rectangleDivStyle} />
        <img
          className={styles.frameItem}
          alt=""
          src="/frame-98.svg"
          style={frameIconStyle}
        />
      </div>
      <div className={styles.rectangleGroup}>
        <div className={styles.frameInner} />
        <div className={styles.frameGroup}>
          <div className={styles.ellipseParent}>
            <div className={styles.ellipseDiv} />
            <div className={styles.gamingLegendsWrapper}>
              <div className={styles.gamingLegends}>Gaming Legends</div>
            </div>
          </div>
          <div className={styles.frameWrapper}>
            <div className={styles.vectorParent}>
              <img className={styles.vectorIcon} alt="" src="/vector110.svg" />
              <div className={styles.kMembersWrapper}>
                <div className={styles.kMembers}>1k Members</div>
              </div>
            </div>
          </div>
        </div>
        <div className={styles.rectangleContainer}>
          <div className={styles.rectangleDiv} />
          <div className={styles.joinCommunity}>Join Community</div>
        </div>
      </div>
    </div>
  );
};

export default FrameComponent23;
