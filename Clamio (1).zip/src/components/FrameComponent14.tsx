import { FunctionComponent } from "react";
import FrameComponent15 from "./FrameComponent15";
import styles from "./FrameComponent14.module.css";

const FrameComponent14: FunctionComponent = () => {
  return (
    <div className={styles.rectangleParent}>
      <div className={styles.frameChild} />
      <div className={styles.frameParent}>
        <div className={styles.reviewsParent}>
          <h3 className={styles.reviews}>Reviews</h3>
          <div className={styles.kWrapper}>
            <div className={styles.k}>4.7(1k)</div>
          </div>
        </div>
        <div className={styles.viewAllWrapper}>
          <div className={styles.viewAll}>View All</div>
        </div>
      </div>
      <div className={styles.frameWrapper}>
        <div className={styles.frameGroup}>
          <FrameComponent15 />
          <FrameComponent15
            propFlex="1"
            propMinWidth="231px"
            propAlignSelf="unset"
          />
          <div className={styles.reviewsAndKWrapper}>
            <FrameComponent15
              propFlex="unset"
              propMinWidth="unset"
              propAlignSelf="stretch"
            />
          </div>
          <FrameComponent15
            propFlex="1"
            propMinWidth="231px"
            propAlignSelf="unset"
          />
        </div>
      </div>
    </div>
  );
};

export default FrameComponent14;
