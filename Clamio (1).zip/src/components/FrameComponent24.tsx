import { FunctionComponent } from "react";
import styles from "./FrameComponent24.module.css";

const FrameComponent24: FunctionComponent = () => {
  return (
    <div className={styles.frameParent}>
      <div className={styles.frameWrapper}>
        <div className={styles.frameGroup}>
          <div className={styles.clamioCommunityWrapper}>
            <h1 className={styles.clamioCommunity}>CLAMIO COMMUNITY</h1>
          </div>
          <h2 className={styles.collaborateAndInteract}>
            Collaborate and Interact with the creators community
          </h2>
        </div>
      </div>
      <div className={styles.frameContainer}>
        <div className={styles.reactpanaParent}>
          <img
            className={styles.reactpanaIcon}
            loading="lazy"
            alt=""
            src="/reactpana.svg"
          />
          <div className={styles.reachOutWrapper}>
            <b className={styles.reachOut}>Reach Out</b>
          </div>
        </div>
        <div className={styles.frameDiv}>
          <div className={styles.groupDiscussioncuateParent}>
            <img
              className={styles.groupDiscussioncuateIcon}
              loading="lazy"
              alt=""
              src="/groupdiscussioncuate.svg"
            />
            <div className={styles.frameWrapper1}>
              <div className={styles.findCommonGroundParent}>
                <b className={styles.findCommonGround}>Find Common Ground</b>
                <div className={styles.frameWrapper2}>
                  <button className={styles.rectangleParent}>
                    <div className={styles.frameChild} />
                    <div className={styles.learnMore}>Learn More</div>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className={styles.startingABusinessProyectamParent}>
          <img
            className={styles.startingABusinessProyectamIcon}
            loading="lazy"
            alt=""
            src="/startingabusinessproyectamico.svg"
          />
          <div className={styles.goClamioWrapper}>
            <b className={styles.goClamio}>Go CLAMIO</b>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FrameComponent24;
