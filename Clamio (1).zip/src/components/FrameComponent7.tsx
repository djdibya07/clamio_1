import { FunctionComponent } from "react";
import styles from "./FrameComponent7.module.css";

export type FrameComponent7Type = {
  you?: string;
  youWillBeCharged125?: string;
  rs100?: string;
  rs875?: string;
};

const FrameComponent7: FunctionComponent<FrameComponent7Type> = ({
  you,
  youWillBeCharged125,
  rs100,
  rs875,
}) => {
  return (
    <div className={styles.rectangleParent}>
      <div className={styles.frameChild} />
      <div className={styles.frameParent}>
        <div className={styles.youWrapper}>
          <h2 className={styles.you}>{you}</h2>
        </div>
        <div className={styles.youWillBe}>{youWillBeCharged125}</div>
      </div>
      <div className={styles.vectorParent}>
        <img
          className={styles.frameItem}
          loading="lazy"
          alt=""
          src="/vector-92.svg"
        />
        <b className={styles.example}>
          <p className={styles.example1}>EXAMPLE</p>
          <p className={styles.blankLine}>&nbsp;</p>
        </b>
      </div>
      <div className={styles.frameGroup}>
        <div className={styles.frameWrapper}>
          <div className={styles.productPriceParent}>
            <div className={styles.productPrice}>
              <p className={styles.productPrice1}>Product price</p>
              <p className={styles.blankLine1}>&nbsp;</p>
            </div>
            <div className={styles.rs100}>
              <p className={styles.rs1001}>Rs. 100</p>
              <p className={styles.blankLine2}>&nbsp;</p>
            </div>
          </div>
        </div>
        <div className={styles.customerPayParent}>
          <div className={styles.customerPay}>
            <p className={styles.customerPay1}>Customer pay</p>
            <p className={styles.blankLine3}>&nbsp;</p>
          </div>
          <div className={styles.rs1002}>
            <p className={styles.rs1003}>{rs100}</p>
            <p className={styles.blankLine4}>&nbsp;</p>
          </div>
        </div>
        <img
          className={styles.frameInner}
          loading="lazy"
          alt=""
          src="/vector-1010.svg"
        />
        <div className={styles.youEarnParent}>
          <div className={styles.youEarn}>{`You earn `}</div>
          <div className={styles.rs875}>
            <p className={styles.rs8751}>{rs875}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FrameComponent7;
