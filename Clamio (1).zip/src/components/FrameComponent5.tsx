import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./FrameComponent5.module.css";

const FrameComponent5: FunctionComponent = () => {
  const navigate = useNavigate();

  const onCOMMUNIITYTextClick = useCallback(() => {
    navigate("/usercreator-community");
  }, [navigate]);

  const onExploreTextClick = useCallback(() => {
    navigate("/product");
  }, [navigate]);

  const onCreatorsTextClick = useCallback(() => {
    // Please sync "Discover Creator" to the project
  }, []);

  const onJoinTextClick = useCallback(() => {
    // Please sync "login and sign up" to the project
  }, []);

  const onButtonClick = useCallback(() => {
    // Please sync "login and sign up" to the project
  }, []);

  const onButton1Click = useCallback(() => {
    navigate("/product");
  }, [navigate]);

  return (
    <section className={styles.logicGateway}>
      <div className={styles.inputFilter}>
        <div className={styles.inputFilterChild} />
        <header className={styles.outputCollector}>
          <div className={styles.createAndSellParent}>
            <b className={styles.createAndSell}>Create and Sell</b>
            <a className={styles.frameWrapper}>
              <nav className={styles.frameParent}>
                <div className={styles.communiityWrapper}>
                  <b
                    className={styles.communiity}
                    onClick={onCOMMUNIITYTextClick}
                  >
                    COMMUNIITY
                  </b>
                </div>
                <b className={styles.explore} onClick={onExploreTextClick}>
                  Explore
                </b>
                <div className={styles.creatorsWrapper}>
                  <b className={styles.creators} onClick={onCreatorsTextClick}>
                    Creators
                  </b>
                </div>
                <b className={styles.join} onClick={onJoinTextClick}>
                  Join
                </b>
              </nav>
            </a>
          </div>
        </header>
        <div className={styles.frameGroup}>
          <div className={styles.frameContainer}>
            <div className={styles.expressionParent}>
              <img
                className={styles.expressionIcon}
                loading="lazy"
                alt=""
                src="/vector.svg"
              />
              <h1 className={styles.discoverTheClamioContainer}>
                <span>{`Discover the `}</span>
                <span className={styles.clamio}>CLAMIO</span>
                <span> Wonderland</span>
              </h1>
            </div>
          </div>
          <div className={styles.frameDiv}>
            <div className={styles.buttonWrapper}>
              <button className={styles.button} onClick={onButtonClick}>
                <b className={styles.joinNow}>Join Now</b>
              </button>
            </div>
            <button className={styles.button1} onClick={onButton1Click}>
              <div className={styles.buttonChild} />
              <b className={styles.browseProducts}>Browse Products</b>
            </button>
          </div>
          <h1 className={styles.createAndSell1}>
            Create and Sell Your Digital Products
          </h1>
        </div>
        <div className={styles.oouilogoWikimediaDiscovery} />
      </div>
    </section>
  );
};

export default FrameComponent5;
