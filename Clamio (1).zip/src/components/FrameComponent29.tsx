import { FunctionComponent } from "react";
import styles from "./FrameComponent29.module.css";

export type FrameComponent29Type = {
  productA?: string;

  /** Action props */
  onFrameContainer5Click?: () => void;
  onEditIconClick?: () => void;
};

const FrameComponent29: FunctionComponent<FrameComponent29Type> = ({
  productA,
  onFrameContainer5Click,
  onEditIconClick,
}) => {
  return (
    <div className={styles.rectangleParent} onClick={onFrameContainer5Click}>
      <div className={styles.frameChild} />
      <div className={styles.frameWrapper}>
        <div className={styles.rectangleGroup}>
          <div className={styles.frameItem} />
          <img
            className={styles.editIcon}
            loading="lazy"
            alt=""
            src="/edit.svg"
            onClick={onEditIconClick}
          />
        </div>
      </div>
      <div className={styles.productAParent}>
        <b className={styles.productA}>{productA}</b>
        <div className={styles.loremIpsumDolorSitAmetCoWrapper}>
          <div className={styles.loremIpsumDolor}>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
            eiusmod tempor
          </div>
        </div>
      </div>
    </div>
  );
};

export default FrameComponent29;
