import { FunctionComponent, useMemo, type CSSProperties } from "react";
import styles from "./FrameComponent1.module.css";

export type FrameComponent1Type = {
  /** Style props */
  browseProductsDisplay?: CSSProperties["display"];
  discoverCreatorsDisplay?: CSSProperties["display"];

  /** Action props */
  onButton5Click?: () => void;
  onButton6Click?: () => void;
};

const FrameComponent1: FunctionComponent<FrameComponent1Type> = ({
  onButton5Click,
  onButton6Click,
  browseProductsDisplay,
  discoverCreatorsDisplay,
}) => {
  const browseProductsStyle: CSSProperties = useMemo(() => {
    return {
      display: browseProductsDisplay,
    };
  }, [browseProductsDisplay]);

  const discoverCreatorsStyle: CSSProperties = useMemo(() => {
    return {
      display: discoverCreatorsDisplay,
    };
  }, [discoverCreatorsDisplay]);

  return (
    <div className={styles.continuePoint}>
      <div className={styles.skipPoint}>
        <button className={styles.button} onClick={onButton5Click}>
          <b className={styles.browseProducts} style={browseProductsStyle}>
            Browse Products
          </b>
        </button>
        <button className={styles.button1} onClick={onButton6Click}>
          <b className={styles.discoverCreators} style={discoverCreatorsStyle}>
            Discover Creators
          </b>
        </button>
      </div>
    </div>
  );
};

export default FrameComponent1;
