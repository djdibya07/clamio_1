import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./FrameComponent3.module.css";

const FrameComponent3: FunctionComponent = () => {
  const navigate = useNavigate();

  const onButtonClick = useCallback(() => {
    navigate("/explore-after-login");
  }, [navigate]);

  return (
    <div className={styles.frameWrapper}>
      <div className={styles.frameParent}>
        <div className={styles.frameGroup}>
          <div className={styles.shapeScalingParent}>
            <div className={styles.shapeScaling}>
              <h1 className={styles.takeHome100Container}>
                <span>Take home</span>
                <span className={styles.span}> 100%</span>
                <span> of your Revenue</span>
              </h1>
            </div>
            <div className={styles.sharePersonalisedLinkContainer}>
              <ul className={styles.sharePersonalisedLinkOnIns}>
                <li className={styles.sharePersonalisedLink}>
                  Share Personalised Link on Instagram
                </li>
                <li className={styles.sellDigitalProducts}>
                  Sell digital products and services
                </li>
                <li
                  className={styles.getPaymentsSecurely}
                >{`Get Payments securely by UPI, Card & Net Banking`}</li>
                <li className={styles.payRs0Per}>
                  Pay Rs.0 per month and Keep up to 100% of revenue*
                </li>
                <li>Get 24/7 support to sell</li>
              </ul>
            </div>
          </div>
          <div className={styles.weCharge125OnEachSuccesWrapper}>
            <div className={styles.weCharge125}>
              *We charge 12.5% on each successful transaction
            </div>
          </div>
        </div>
        <div className={styles.shapeRebasingWrapper}>
          <div className={styles.shapeRebasing}>
            <div className={styles.dataAggregator}>
              <div className={styles.clamioPremium}>Clamio Premium</div>
            </div>
            <div className={styles.inputFilter}>
              <h1 className={styles.rs0}>Rs 0/-</h1>
            </div>
            <div className={styles.subroutine}>
              <div className={styles.productListing}>
                <ul className={styles.productListing1}>
                  <li>Product Listing</li>
                </ul>
              </div>
              <div className={styles.personalisedDashboard}>
                <ul className={styles.personalisedDashboard1}>
                  <li>Personalised Dashboard</li>
                </ul>
              </div>
              <div className={styles.support}>
                <ul className={styles.support1}>
                  <li>24/7 Support</li>
                </ul>
              </div>
              <div className={styles.variableHolder}>
                <div className={styles.gbStorage}>
                  <ul className={styles.gbStorage1}>
                    <li>5 GB Storage</li>
                  </ul>
                </div>
                <div className={styles.functionCaller}>
                  <button className={styles.button} onClick={onButtonClick}>
                    <b className={styles.getStarted}>Get Started</b>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FrameComponent3;
