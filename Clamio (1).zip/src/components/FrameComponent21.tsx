import { FunctionComponent } from "react";
import styles from "./FrameComponent21.module.css";

const FrameComponent21: FunctionComponent = () => {
  return (
    <footer className={styles.rectangleParent}>
      <div className={styles.frameChild} />
      <div className={styles.rectangleGroup}>
        <div className={styles.frameItem} />
        <h1 className={styles.setupACommunity}>Setup a Community</h1>
      </div>
      <div className={styles.frameWrapper}>
        <div className={styles.goClamioNowParent}>
          <h2 className={styles.goClamioNow}>Go CLAMIO Now!!</h2>
          <div className={styles.reachOutTo}>
            Reach out to like minded Creators and Followers, expand your
            audience, find your common interest and GROW with CLAMIO
          </div>
        </div>
      </div>
    </footer>
  );
};

export default FrameComponent21;
