import { FunctionComponent, useCallback } from "react";
import styles from "./InstanceInstigator.module.css";

const InstanceInstigator: FunctionComponent = () => {
  const onButtonClick = useCallback(() => {
    // Please sync "Discover Creator" to the project
  }, []);

  return (
    <div className={styles.instanceInstigator}>
      <h1 className={styles.meetTheClamioContainer}>
        <span>{`Meet the `}</span>
        <span className={styles.clamio}>CLAMIO</span>
        <span> Creator</span>
      </h1>
      <div className={styles.frameParent}>
        <div className={styles.frameGroup}>
          <div className={styles.frameContainer}>
            <div className={styles.frameWrapper}>
              <div className={styles.welcomeToTheCreatorsStageParent}>
                <div className={styles.welcomeToThe}>
                  Welcome to the creators’ stage, where the magic happens! Say
                  hello to an eclectic mix of artists, experts and storytellers,
                  all ready to enchant you with their digital masterpieces.
                </div>
                <div className={styles.discoverTheMinds}>
                  Discover the minds behind your favorite digital products and
                  follow them to stay updated with their latest works. Whether
                  you're an e-sports enthusiast, a health-conscious individual,
                  a spiritual seeker, a travel aficionado, or a food lover,
                  you're bound to discover a creator who speaks to your
                  interests
                </div>
              </div>
            </div>
            <div className={styles.joinACommunity}>
              Join a community that’s teeming with talent and be the first to
              know about fresh releases, upcoming events, and exclusive goodies
              from these maestros of the digital realm!
            </div>
          </div>
          <div className={styles.buttonWrapper}>
            <button className={styles.button} onClick={onButtonClick}>
              <b className={styles.browseCreators}>Browse Creators</b>
            </button>
          </div>
        </div>
        <div className={styles.designProcesscuateWrapper}>
          <img
            className={styles.designProcesscuateIcon}
            loading="lazy"
            alt=""
            src="/designprocesscuate.svg"
          />
        </div>
      </div>
    </div>
  );
};

export default InstanceInstigator;
