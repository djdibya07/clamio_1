import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./FrameComponent27.module.css";

const FrameComponent27: FunctionComponent = () => {
  const navigate = useNavigate();

  const onFrameContainerClick = useCallback(() => {
    navigate("/creator-login");
  }, [navigate]);

  return (
    <section className={styles.frameParent}>
      <div className={styles.gettingStartedIsEasyWrapper}>
        <h1 className={styles.gettingStartedIs}>Getting Started is Easy</h1>
      </div>
      <div className={styles.frameGroup}>
        <div className={styles.frameContainer}>
          <div className={styles.frameWrapper}>
            <img
              className={styles.frameChild}
              loading="lazy"
              alt=""
              src="/frame-117.svg"
            />
          </div>
          <h1 className={styles.signIn}>Sign in</h1>
          <div className={styles.getRegisteredThroughClamioWrapper}>
            <div className={styles.getRegisteredThrough}>
              Get Registered through CLAMIO with ZERO Registration Charges
            </div>
          </div>
        </div>
        <div className={styles.frameDiv}>
          <div className={styles.frameWrapper1}>
            <img
              className={styles.frameItem}
              loading="lazy"
              alt=""
              src="/frame-119.svg"
            />
          </div>
          <div className={styles.earnPointsParent}>
            <h1 className={styles.earnPoints}>Earn Points</h1>
            <div className={styles.earnClamioRewardPointsOnEWrapper}>
              <div
                className={styles.earnClamioReward}
              >{`Earn CLAMIO reward points on every referral and product sell `}</div>
            </div>
          </div>
        </div>
        <div className={styles.frameParent1}>
          <div className={styles.frameWrapper2}>
            <img
              className={styles.frameInner}
              loading="lazy"
              alt=""
              src="/frame-118.svg"
            />
          </div>
          <div className={styles.viewRewardsWrapper}>
            <h1 className={styles.viewRewards}>View Rewards</h1>
          </div>
          <div className={styles.frameParent2}>
            <div className={styles.getAccessToYourPersonaliseWrapper}>
              <div className={styles.getAccessTo}>
                Get access to your personalised rewards dashboard
              </div>
            </div>
            <div className={styles.frameParent3}>
              <div className={styles.frameWrapper3}>
                <div
                  className={styles.frameWrapper4}
                  onClick={onFrameContainerClick}
                >
                  <button className={styles.rectangleParent}>
                    <div className={styles.rectangleDiv} />
                    <b className={styles.startSelling}>START SELLING</b>
                  </button>
                </div>
              </div>
              <h1 className={styles.gettingRewardIs}>Getting Reward is Easy</h1>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FrameComponent27;
