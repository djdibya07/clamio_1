import { FunctionComponent } from "react";
import styles from "./FrameComponent19.module.css";

const FrameComponent19: FunctionComponent = () => {
  return (
    <div className={styles.frameParent}>
      <div className={styles.frameWrapper}>
        <div className={styles.frameGroup}>
          <div className={styles.rectangleParent}>
            <div className={styles.frameChild} />
            <b className={styles.all}>All</b>
          </div>
          <div className={styles.categoryParent}>
            <b className={styles.category}>Category</b>
            <b className={styles.category1}>Category</b>
            <b className={styles.category2}>Category</b>
            <b className={styles.category3}>Category</b>
            <b className={styles.category4}>Category</b>
            <b className={styles.category5}>Category</b>
            <b className={styles.category6}>Category</b>
            <b className={styles.category7}>Category</b>
          </div>
          <img
            className={styles.gridiconsdropdown}
            alt=""
            src="/gridiconsdropdown1.svg"
          />
          <b className={styles.more}>more</b>
        </div>
      </div>
      <img className={styles.frameItem} alt="" src="/vector-410.svg" />
    </div>
  );
};

export default FrameComponent19;
