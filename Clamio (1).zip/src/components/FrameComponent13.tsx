import { FunctionComponent, useMemo, type CSSProperties } from "react";
import styles from "./FrameComponent13.module.css";

export type FrameComponent13Type = {
  feature3?: string;
  feature7?: string;

  /** Style props */
  propPadding?: CSSProperties["padding"];
  propPadding1?: CSSProperties["padding"];
  propPadding2?: CSSProperties["padding"];
};

const FrameComponent13: FunctionComponent<FrameComponent13Type> = ({
  feature3,
  feature7,
  propPadding,
  propPadding1,
  propPadding2,
}) => {
  const frameDivStyle: CSSProperties = useMemo(() => {
    return {
      padding: propPadding,
    };
  }, [propPadding]);

  const frameDiv1Style: CSSProperties = useMemo(() => {
    return {
      padding: propPadding1,
    };
  }, [propPadding1]);

  const frameButtonStyle: CSSProperties = useMemo(() => {
    return {
      padding: propPadding2,
    };
  }, [propPadding2]);

  return (
    <div className={styles.frameParent}>
      <div className={styles.frameGroup}>
        <div className={styles.feature3Wrapper} style={frameDivStyle}>
          <b className={styles.feature3}>{feature3}</b>
        </div>
        <button className={styles.rectangleParent}>
          <div className={styles.frameChild} />
          <b className={styles.inputArea}>input area</b>
        </button>
      </div>
      <div className={styles.frameWrapper}>
        <div className={styles.frameContainer}>
          <div className={styles.feature7Wrapper} style={frameDiv1Style}>
            <b className={styles.feature7}>{feature7}</b>
          </div>
          <button className={styles.rectangleGroup} style={frameButtonStyle}>
            <div className={styles.frameItem} />
            <b className={styles.inputArea1}>input area</b>
          </button>
        </div>
      </div>
    </div>
  );
};

export default FrameComponent13;
