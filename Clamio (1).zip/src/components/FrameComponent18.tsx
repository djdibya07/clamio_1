import { FunctionComponent } from "react";
import styles from "./FrameComponent18.module.css";

const FrameComponent18: FunctionComponent = () => {
  return (
    <section className={styles.frameParent}>
      <div className={styles.rectangleWrapper}>
        <div className={styles.frameChild} />
      </div>
      <div className={styles.frameGroup}>
        <div className={styles.frameContainer}>
          <div className={styles.beverageAnimationWrapper}>
            <h3 className={styles.beverageAnimation}>Beverage Animation</h3>
          </div>
          <div className={styles.ellipseParent}>
            <div className={styles.frameItem} />
            <div className={styles.davidJackoffWrapper}>
              <div className={styles.davidJackoff}>David Jackoff</div>
            </div>
          </div>
          <div className={styles.frameWrapper}>
            <div className={styles.frameDiv}>
              <img
                className={styles.frameInner}
                loading="lazy"
                alt=""
                src="/frame-77.svg"
              />
              <div className={styles.kWrapper}>
                <div className={styles.k}>4.7(1k)</div>
              </div>
            </div>
          </div>
          <div className={styles.loremIpsumDolorSitAmetCoWrapper}>
            <div className={styles.loremIpsumDolor}>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
              eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
              enim ad minim veniam, quis nostrud exercitation ullamco laboris
              nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in
              reprehenderit in voluptate velit esse cillum dolore eu fugiat
              nulla pariatur. Excepteur sint occaecat cupidatat non proident,
              sunt in culpa qui officia deserunt mollit anim id est laborum.
            </div>
          </div>
          <div className={styles.wrapper}>
            <div className={styles.div}>$25</div>
          </div>
        </div>
        <div className={styles.frameWrapper1}>
          <div className={styles.frameParent1}>
            <div className={styles.frameWrapper2}>
              <button className={styles.rectangleParent}>
                <div className={styles.rectangleDiv} />
                <b className={styles.addToCart}>Add To Cart</b>
              </button>
            </div>
            <button className={styles.rectangleGroup}>
              <div className={styles.frameChild1} />
              <b className={styles.buyNow}>Buy Now</b>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FrameComponent18;
