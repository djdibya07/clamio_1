import { FunctionComponent } from "react";
import styles from "./FrameComponent25.module.css";

const FrameComponent25: FunctionComponent = () => {
  return (
    <section className={styles.frameParent}>
      <div className={styles.frameGroup}>
        <div className={styles.mdistarCircleWrapper}>
          <img
            className={styles.mdistarCircleIcon}
            loading="lazy"
            alt=""
            src="/mdistarcircle.svg"
          />
        </div>
        <div className={styles.frameContainer}>
          <div className={styles.clamioDebutWrapper}>
            <h1 className={styles.clamioDebut}>
              <b>CLAMIO</b>
              <span className={styles.debut}> Debut</span>
            </h1>
          </div>
          <div className={styles.sale1Referral}>
            <ul className={styles.sale1Referral1}>
              <li>{`1 Sale/1 Referral `}</li>
            </ul>
          </div>
        </div>
      </div>
      <div className={styles.frameDiv}>
        <div className={styles.mdishieldStarOutlineWrapper}>
          <img
            className={styles.mdishieldStarOutlineIcon}
            loading="lazy"
            alt=""
            src="/mdishieldstaroutline.svg"
          />
        </div>
        <div className={styles.frameParent1}>
          <div className={styles.clamioStarWrapper}>
            <h1 className={styles.clamioStar}>
              <b>CLAMIO</b>
              <span className={styles.star}> Star</span>
            </h1>
          </div>
          <div className={styles.sale25ReferralsContainer}>
            <ul className={styles.sale25ReferralsRedeemYour}>
              <li className={styles.sale25Referrals}>100 Sale/ 25 Referrals</li>
              <li>Redeem your CLAMIO Coins</li>
            </ul>
          </div>
        </div>
      </div>
      <div className={styles.frameParent2}>
        <div className={styles.mdishieldStarWrapper}>
          <img
            className={styles.mdishieldStarIcon}
            loading="lazy"
            alt=""
            src="/mdishieldstar.svg"
          />
        </div>
        <div className={styles.frameParent3}>
          <div className={styles.clamioBossWrapper}>
            <h1 className={styles.clamioBoss}>
              <b>CLAMIO</b>
              <span className={styles.boss}> Boss</span>
            </h1>
          </div>
          <div className={styles.salesRedeemYourContainer}>
            <ul className={styles.salesRedeemYourClamioCoins}>
              <li className={styles.sales}>5000 Sales</li>
              <li className={styles.redeemYourClamio}>
                Redeem your CLAMIO Coins
              </li>
              <li>4.5% Discount on Transactional Charges</li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FrameComponent25;
