import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./FrameComponent9.module.css";

const FrameComponent9: FunctionComponent = () => {
  const navigate = useNavigate();

  const onIcbaselinePlusClick = useCallback(() => {
    navigate("/create-product-page");
  }, [navigate]);

  const onFrameContainer1Click = useCallback(() => {
    navigate("/create-product-page");
  }, [navigate]);

  return (
    <div className={styles.rectangleParent}>
      <div className={styles.frameChild} data-scroll-to="rectangle" />
      <div className={styles.icbaselinePlusWrapper}>
        <button
          className={styles.icbaselinePlus}
          onClick={onIcbaselinePlusClick}
        >
          <div className={styles.icbaselinePlusChild} />
          <img className={styles.vectorIcon} alt="" src="/vector40.svg" />
        </button>
      </div>
      <div className={styles.vectorParent} onClick={onFrameContainer1Click}>
        <img className={styles.frameItem} alt="" src="/rectangle-30.svg" />
        <h3 className={styles.createYourProduct}>Create Your Product</h3>
      </div>
    </div>
  );
};

export default FrameComponent9;
