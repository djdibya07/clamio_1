import { FunctionComponent, useMemo, type CSSProperties } from "react";
import styles from "./FrameComponent11.module.css";

export type FrameComponent11Type = {
  /** Style props */
  propTop?: CSSProperties["top"];
  propLeft?: CSSProperties["left"];
};

const FrameComponent11: FunctionComponent<FrameComponent11Type> = ({
  propTop,
  propLeft,
}) => {
  const createProductPageStyle: CSSProperties = useMemo(() => {
    return {
      top: propTop,
      left: propLeft,
    };
  }, [propTop, propLeft]);

  return (
    <div className={styles.createProductPage} style={createProductPageStyle}>
      <div className={styles.createProductPageChild} />
      <div className={styles.createProductPageInner}>
        <div className={styles.frameChild} />
      </div>
      <div className={styles.categoryNameParent}>
        <b className={styles.categoryName}>Category Name</b>
        <div className={styles.loremIpsumDolorSitAmetCoWrapper}>
          <div className={styles.loremIpsumDolor}>
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
            eiusmod tempor
          </div>
        </div>
      </div>
    </div>
  );
};

export default FrameComponent11;
