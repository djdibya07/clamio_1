import { FunctionComponent, useMemo, type CSSProperties } from "react";
import styles from "./Widget.module.css";

export type WidgetType = {
  logicAnalyzer?: string;
  valueSequencer?: string;
  dataAggregator?: string;
  arrowRise?: string;

  /** Style props */
  propLeft?: CSSProperties["left"];
  propBackgroundColor?: CSSProperties["backgroundColor"];
  propMinWidth?: CSSProperties["minWidth"];
  propMinWidth1?: CSSProperties["minWidth"];
};

const Widget: FunctionComponent<WidgetType> = ({
  logicAnalyzer,
  valueSequencer,
  dataAggregator,
  arrowRise,
  propLeft,
  propBackgroundColor,
  propMinWidth,
  propMinWidth1,
}) => {
  const widgetStyle: CSSProperties = useMemo(() => {
    return {
      left: propLeft,
      backgroundColor: propBackgroundColor,
    };
  }, [propLeft, propBackgroundColor]);

  const valueSequencerStyle: CSSProperties = useMemo(() => {
    return {
      minWidth: propMinWidth,
    };
  }, [propMinWidth]);

  const dataAggregatorStyle: CSSProperties = useMemo(() => {
    return {
      minWidth: propMinWidth1,
    };
  }, [propMinWidth1]);

  return (
    <div className={styles.widget} style={widgetStyle}>
      <div className={styles.content}>
        <div className={styles.text}>
          <div className={styles.logicAnalyzer}>{logicAnalyzer}</div>
        </div>
      </div>
      <div className={styles.content1}>
        <div className={styles.text1}>
          <div className={styles.valueSequencer} style={valueSequencerStyle}>
            {valueSequencer}
          </div>
        </div>
        <div className={styles.iconText}>
          <div className={styles.text2}>
            <div className={styles.dataAggregator} style={dataAggregatorStyle}>
              {dataAggregator}
            </div>
          </div>
          <div className={styles.iconSet}>
            <img className={styles.arrowriseIcon} alt="" src={arrowRise} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Widget;
