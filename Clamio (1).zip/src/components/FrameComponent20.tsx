import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./FrameComponent20.module.css";

const FrameComponent20: FunctionComponent = () => {
  const navigate = useNavigate();

  const onCLAMIOTextClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  return (
    <header className={styles.productInner}>
      <div className={styles.frameParent}>
        <div className={styles.clamioParent}>
          <h1 className={styles.clamio} onClick={onCLAMIOTextClick}>
            CLAMIO
          </h1>
          <div className={styles.frameWrapper}>
            <div className={styles.rectangleParent}>
              <div className={styles.frameChild} />
              <img className={styles.bisearchIcon} alt="" src="/bisearch.svg" />
              <div className={styles.searchCreatorWrapper}>
                <div className={styles.searchCreator}>Search Creator</div>
              </div>
            </div>
          </div>
        </div>
        <div className={styles.sellYourProductWrapper}>
          <b className={styles.sellYourProduct}>Sell Your Product</b>
        </div>
        <div className={styles.frameContainer}>
          <div className={styles.likeParent}>
            <img
              className={styles.likeIcon}
              loading="lazy"
              alt=""
              src="/like.svg"
            />
            <img
              className={styles.cartIcon}
              loading="lazy"
              alt=""
              src="/cart1.svg"
            />
          </div>
        </div>
      </div>
    </header>
  );
};

export default FrameComponent20;
