import { FunctionComponent } from "react";
import FrameComponent13 from "./FrameComponent13";
import styles from "./FrameComponent12.module.css";

const FrameComponent12: FunctionComponent = () => {
  return (
    <div className={styles.rectangleParent}>
      <div className={styles.frameChild} />
      <div className={styles.yourProductHighlightsWrapper}>
        <h2 className={styles.yourProductHighlights}>
          Your Product Highlights
        </h2>
      </div>
      <div className={styles.frameParent}>
        <div className={styles.frameGroup}>
          <div className={styles.frameContainer}>
            <div className={styles.feature1Wrapper}>
              <b className={styles.feature1}>Feature 1</b>
            </div>
            <button className={styles.rectangleGroup}>
              <div className={styles.frameItem} />
              <b className={styles.inputArea}>input area</b>
            </button>
          </div>
          <div className={styles.frameDiv}>
            <div className={styles.feature5Wrapper}>
              <b className={styles.feature5}>Feature 5</b>
            </div>
            <button className={styles.rectangleContainer}>
              <div className={styles.frameInner} />
              <b className={styles.inputArea1}>input area</b>
            </button>
          </div>
        </div>
        <div className={styles.frameParent1}>
          <div className={styles.frameParent2}>
            <div className={styles.frameParent3}>
              <div className={styles.feature2Wrapper}>
                <b className={styles.feature2}>Feature 2</b>
              </div>
              <button className={styles.frameButton}>
                <div className={styles.rectangleDiv} />
                <b className={styles.inputArea2}>input area</b>
              </button>
            </div>
            <div className={styles.frameParent4}>
              <div className={styles.feature6Wrapper}>
                <b className={styles.feature6}>Feature 6</b>
              </div>
              <button className={styles.rectangleParent1}>
                <div className={styles.frameChild1} />
                <b className={styles.inputArea3}>input area</b>
              </button>
            </div>
          </div>
          <div className={styles.frameParent5}>
            <FrameComponent13 feature3="Feature 3" feature7="Feature 7" />
            <FrameComponent13
              feature3="Feature 4"
              feature7="Feature 8"
              propPadding="var(--padding-3xl) 0px 0px"
              propPadding1="var(--padding-sm) 0px 0px"
              propPadding2="var(--padding-xl) var(--padding-xl) var(--padding-4xl)"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default FrameComponent12;
