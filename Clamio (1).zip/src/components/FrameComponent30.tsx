import { FunctionComponent } from "react";
import FrameComponent17 from "./FrameComponent17";
import styles from "./FrameComponent30.module.css";

const FrameComponent30: FunctionComponent = () => {
  return (
    <div className={styles.rectangleParent}>
      <div className={styles.frameChild} />
      <div className={styles.productHighlightsWrapper}>
        <h2 className={styles.productHighlights}>Product Highlights</h2>
      </div>
      <div className={styles.frameParent}>
        <FrameComponent17
          easyToUse="Easy to use"
          propPadding="0px var(--padding-58xl)"
          propAlignSelf="unset"
        />
        <FrameComponent17
          easyToUse="Easy Returns"
          propPadding="0px var(--padding-53xl)"
          propAlignSelf="stretch"
        />
        <FrameComponent17
          easyToUse="Result in 10 days"
          propPadding="0px var(--padding-53xl)"
          propAlignSelf="stretch"
        />
        <FrameComponent17
          easyToUse="Google certified"
          propPadding="0px var(--padding-53xl)"
          propAlignSelf="stretch"
        />
      </div>
    </div>
  );
};

export default FrameComponent30;
