import { FunctionComponent } from "react";
import FrameComponent23 from "./FrameComponent23";
import styles from "./FrameComponent22.module.css";

const FrameComponent22: FunctionComponent = () => {
  return (
    <section className={styles.usercreatorCommunityInner}>
      <div className={styles.frameParent}>
        <div className={styles.frameWrapper}>
          <div className={styles.rectangleParent}>
            <div className={styles.frameChild} />
            <div className={styles.findMyCommunityWrapper}>
              <h3 className={styles.findMyCommunity}>Find My Community</h3>
            </div>
            <div className={styles.rectangleGroup}>
              <div className={styles.frameItem} />
              <img
                className={styles.bisearchIcon}
                loading="lazy"
                alt=""
                src="/bisearch.svg"
              />
              <div className={styles.searchCommunityWrapper}>
                <div className={styles.searchCommunity}>Search Community</div>
              </div>
            </div>
          </div>
        </div>
        <div className={styles.frameGroup}>
          <div className={styles.frameContainer}>
            <div className={styles.frameDiv}>
              <img className={styles.frameInner} alt="" src="/frame-58.svg" />
              <div className={styles.rectangleDiv} />
              <img
                className={styles.frameIcon}
                loading="lazy"
                alt=""
                src="/frame-98.svg"
              />
            </div>
            <div className={styles.rectangleContainer}>
              <div className={styles.frameChild1} />
              <div className={styles.gamingLegendsParent}>
                <div className={styles.gamingLegends}>Gaming Legends</div>
                <div className={styles.ellipseDiv} />
                <div className={styles.kMembers}>1k Members</div>
                <img className={styles.starIcon} alt="" src="/star1.svg" />
                <div className={styles.frameChild2} />
                <div className={styles.joinCommunity}>Join Community</div>
                <div className={styles.frameChild3} />
                <div className={styles.frameParent1}>
                  <div className={styles.ellipseParent}>
                    <div className={styles.frameChild4} />
                    <div className={styles.gamingLegendsWrapper}>
                      <div className={styles.gamingLegends1}>
                        Gaming Legends
                      </div>
                    </div>
                  </div>
                  <div className={styles.frameWrapper1}>
                    <div className={styles.vectorParent}>
                      <img
                        className={styles.vectorIcon}
                        loading="lazy"
                        alt=""
                        src="/vector110.svg"
                      />
                      <div className={styles.kMembersWrapper}>
                        <div className={styles.kMembers1}>1k Members</div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className={styles.rectangleParent1}>
                  <div className={styles.frameChild5} />
                  <div className={styles.joinCommunity1}>Join Community</div>
                </div>
              </div>
            </div>
          </div>
          <div className={styles.frameWrapper2}>
            <FrameComponent23 />
          </div>
          <FrameComponent23
            propFlex="unset"
            propWidth="287px"
            propAlignSelf="stretch"
            propFlex1="1"
            propPadding="0px 0px var(--padding-196xl)"
            propHeight="unset"
            propPosition="unset"
            propHeight1="265px"
            propAlignSelf1="unset"
            propPosition1="relative"
            propMargin="unset"
            propTop="unset"
            propRight="unset"
          />
          <FrameComponent23
            propFlex="unset"
            propWidth="287px"
            propAlignSelf="unset"
            propFlex1="unset"
            propPadding="unset"
            propHeight="265px"
            propPosition="relative"
            propHeight1="unset"
            propAlignSelf1="stretch"
            propPosition1="absolute"
            propMargin="0 !important"
            propTop="0px"
            propRight="0px"
          />
        </div>
      </div>
    </section>
  );
};

export default FrameComponent22;
