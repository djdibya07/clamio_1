import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./FrameComponent8.module.css";

const FrameComponent8: FunctionComponent = () => {
  const navigate = useNavigate();

  const onCOMMUNIITYTextClick = useCallback(() => {
    navigate("/usercreator-community");
  }, [navigate]);

  const onExploreTextClick = useCallback(() => {
    navigate("/product");
  }, [navigate]);

  const onCreatorsTextClick = useCallback(() => {
    // Please sync "Discover Creator" to the project
  }, []);

  const onDashboardTextClick = useCallback(() => {
    // Please sync "login and sign up" to the project
  }, []);

  const onFrameButtonClick = useCallback(() => {
    navigate("/creator-login");
  }, [navigate]);

  return (
    <section className={styles.beAClamioCreatorNowParent}>
      <h1 className={styles.beAClamioContainer}>
        <p className={styles.beAClamioCreator}>
          <span className={styles.beA}>{`Be a `}</span>
          <span className={styles.clamio}>CLAMIO</span>
          <span> Creator</span>
        </p>
        <p className={styles.now}>Now!</p>
      </h1>
      <div className={styles.rectangleParent}>
        <div className={styles.frameChild} />
        <header className={styles.createAndSellParent}>
          <b className={styles.createAndSell}>Create and Sell</b>
          <nav className={styles.frameWrapper}>
            <nav className={styles.frameParent}>
              <div className={styles.communiityWrapper}>
                <b
                  className={styles.communiity}
                  onClick={onCOMMUNIITYTextClick}
                >
                  COMMUNIITY
                </b>
              </div>
              <b className={styles.explore} onClick={onExploreTextClick}>
                Explore
              </b>
              <b className={styles.creators} onClick={onCreatorsTextClick}>
                Creators
              </b>
              <b className={styles.dashboard} onClick={onDashboardTextClick}>
                Dashboard
              </b>
            </nav>
          </nav>
        </header>
        <div className={styles.frameContainer}>
          <div className={styles.imaginationcuateParent}>
            <img
              className={styles.imaginationcuateIcon}
              loading="lazy"
              alt=""
              src="/imaginationcuate.svg"
            />
            <div className={styles.frameDiv}>
              <button
                className={styles.rectangleGroup}
                onClick={onFrameButtonClick}
              >
                <div className={styles.frameItem} />
                <b className={styles.startSelling}>START SELLING</b>
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FrameComponent8;
