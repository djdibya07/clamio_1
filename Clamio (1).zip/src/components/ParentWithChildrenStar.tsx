import { FunctionComponent, useMemo, type CSSProperties } from "react";
import styles from "./ParentWithChildrenStar.module.css";

export type ParentWithChildrenStarType = {
  /** Style props */
  propAlignSelf?: CSSProperties["alignSelf"];
  propWidth?: CSSProperties["width"];
  propFlex?: CSSProperties["flex"];
  propMinWidth?: CSSProperties["minWidth"];
  propFlex1?: CSSProperties["flex"];
  propHeight?: CSSProperties["height"];
};

const ParentWithChildrenStar: FunctionComponent<ParentWithChildrenStarType> = ({
  propAlignSelf,
  propWidth,
  propFlex,
  propMinWidth,
  propFlex1,
  propHeight,
}) => {
  const parentWithChildrenStarStyle: CSSProperties = useMemo(() => {
    return {
      alignSelf: propAlignSelf,
      width: propWidth,
      flex: propFlex,
      minWidth: propMinWidth,
    };
  }, [propAlignSelf, propWidth, propFlex, propMinWidth]);

  const frameDiv4Style: CSSProperties = useMemo(() => {
    return {
      flex: propFlex1,
      height: propHeight,
    };
  }, [propFlex1, propHeight]);

  return (
    <div
      className={styles.parentWithChildrenStar}
      style={parentWithChildrenStarStyle}
    >
      <div className={styles.rectangleParent} style={frameDiv4Style}>
        <div className={styles.frameChild} />
        <img
          className={styles.frameItem}
          loading="lazy"
          alt=""
          src="/frame-58.svg"
        />
      </div>
      <div className={styles.productAniBevAnim}>
        <div className={styles.productAniBevAnimChild} />
        <div className={styles.frameParent}>
          <div className={styles.beverageAnimationWrapper}>
            <b className={styles.beverageAnimation}>Beverage Animation</b>
          </div>
          <img
            className={styles.cartIcon}
            loading="lazy"
            alt=""
            src="/cart.svg"
          />
        </div>
        <div className={styles.frameGroup}>
          <div className={styles.ellipseParent}>
            <div className={styles.frameInner} />
            <div className={styles.davidJackoffWrapper}>
              <div className={styles.davidJackoff}>David Jackoff</div>
            </div>
          </div>
          <div className={styles.frameWrapper}>
            <div className={styles.starParent}>
              <img
                className={styles.starIcon}
                loading="lazy"
                alt=""
                src="/star1.svg"
              />
              <div className={styles.kWrapper}>
                <div className={styles.k}>4.7(1k)</div>
              </div>
            </div>
          </div>
        </div>
        <div className={styles.wrapper}>
          <div className={styles.div}>$25</div>
        </div>
      </div>
    </div>
  );
};

export default ParentWithChildrenStar;
