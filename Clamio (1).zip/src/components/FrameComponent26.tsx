import { FunctionComponent } from "react";
import styles from "./FrameComponent26.module.css";

const FrameComponent26: FunctionComponent = () => {
  return (
    <section className={styles.rewardsInner}>
      <div className={styles.frameParent}>
        <div className={styles.frameGroup}>
          <div className={styles.frameWrapper}>
            <div className={styles.categoryParent}>
              <div className={styles.category}>Category</div>
              <div className={styles.category1}>Category</div>
              <div className={styles.category2}>Category</div>
              <div className={styles.category3}>Category</div>
              <div className={styles.category4}>Category</div>
            </div>
          </div>
          <div className={styles.frameContainer}>
            <div className={styles.frameDiv}>
              <div className={styles.frameParent1}>
                <div className={styles.referToCreatorsParent}>
                  <h1 className={styles.referToCreators}>Refer to Creators</h1>
                  <div className={styles.onEverySuccessfulReferralYWrapper}>
                    <div className={styles.onEverySuccessfulContainer}>
                      <p className={styles.onEverySuccessful}>
                        On every successful referral you will earn 500 CLAMIO
                        Reward Coins.
                      </p>
                      <p className={styles.every100Coin}>
                        Every 100 coin = Rs. 1
                      </p>
                    </div>
                  </div>
                </div>
                <div className={styles.selfConfidencebroWrapper}>
                  <img
                    className={styles.selfConfidencebroIcon}
                    loading="lazy"
                    alt=""
                    src="/selfconfidencebro.svg"
                  />
                </div>
              </div>
            </div>
            <div className={styles.frameParent2}>
              <div className={styles.referAFriendpanaWrapper}>
                <img
                  className={styles.referAFriendpanaIcon}
                  loading="lazy"
                  alt=""
                  src="/referafriendpana.svg"
                />
              </div>
              <div className={styles.sell100ProductsParent}>
                <h1 className={styles.sell100Products}>Sell 100 Products</h1>
                <div className={styles.onEverySuccessfulSaleOf10Wrapper}>
                  <div className={styles.onEverySuccessfulContainer1}>
                    <p className={styles.onEverySuccessful1}>
                      On every successful sale of 100 Product you will earn
                      10,000 CLAMIO Reward Coins.
                    </p>
                    <p className={styles.every100Coin1}>
                      Every 100 coin = Rs. 1
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className={styles.howToLevelUpAndEarnRewarWrapper}>
          <h1 className={styles.howToLevel}>
            How to Level up and Earn Rewards
          </h1>
        </div>
      </div>
    </section>
  );
};

export default FrameComponent26;
