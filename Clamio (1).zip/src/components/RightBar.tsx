import { FunctionComponent } from "react";
import styles from "./RightBar.module.css";

const RightBar: FunctionComponent = () => {
  return (
    <div className={styles.rightbar}>
      <div className={styles.geometryTransformer}>
        <div className={styles.text}>
          <div className={styles.conditionChecker}>Notifications</div>
        </div>
        <div className={styles.iconText}>
          <div className={styles.iconSet}>
            <img className={styles.bugbeetleIcon} alt="" src="/bugbeetle.svg" />
          </div>
          <div className={styles.text1}>
            <div className={styles.variableHolder}>
              You have a pro that needs to be fixed.
            </div>
            <div className={styles.iterationController}>Just now</div>
          </div>
        </div>
        <div className={styles.iconText1}>
          <div className={styles.iconSet1}>
            <img className={styles.userIcon} alt="" src="/user.svg" />
          </div>
          <div className={styles.text2}>
            <div className={styles.text3}>New user registered</div>
            <div className={styles.text4}>59 minutes ago</div>
          </div>
        </div>
        <div className={styles.iconText2}>
          <div className={styles.iconSet2}>
            <img
              className={styles.bugbeetleIcon1}
              alt=""
              src="/bugbeetle.svg"
            />
          </div>
          <div className={styles.text5}>
            <div className={styles.text6}>You have encountered issue</div>
            <div className={styles.text7}>12 hours ago</div>
          </div>
        </div>
        <div className={styles.iconText3}>
          <div className={styles.iconSet3}>
            <img className={styles.broadcastIcon} alt="" src="/broadcast.svg" />
          </div>
          <div className={styles.text8}>
            <div className={styles.text9}>Andi Lane subscribed to you</div>
            <div className={styles.text10}>Today, 11:59 AM</div>
          </div>
        </div>
      </div>
      <div className={styles.outputFormatter}>
        <div className={styles.text11}>
          <div className={styles.propertySetter}>Activities</div>
        </div>
        <div className={styles.iconText4}>
          <div className={styles.iconSet4}>
            <img
              className={styles.d05Icon}
              loading="lazy"
              alt=""
              src="/3d05@2x.png"
            />
          </div>
          <div className={styles.text12}>
            <div className={styles.filterProcessor}>
              You have a pro that needs to be fixed.
            </div>
            <div className={styles.triggerHandler}>Just now</div>
          </div>
        </div>
        <div className={styles.iconText5}>
          <div className={styles.iconSet5}>
            <img
              className={styles.female05Icon}
              loading="lazy"
              alt=""
              src="/female05@2x.png"
            />
          </div>
          <div className={styles.text13}>
            <div className={styles.text14}>Released a new product</div>
            <div className={styles.text15}>59 minutes ago</div>
          </div>
        </div>
        <div className={styles.iconText6}>
          <div className={styles.iconSet6}>
            <img
              className={styles.d08Icon}
              loading="lazy"
              alt=""
              src="/3d08@2x.png"
            />
          </div>
          <div className={styles.text16}>
            <div className={styles.text17}>Submitted a edit</div>
            <div className={styles.text18}>12 hours ago</div>
          </div>
        </div>
        <div className={styles.iconText7}>
          <div className={styles.iconSet7}>
            <img
              className={styles.male07Icon}
              loading="lazy"
              alt=""
              src="/male07@2x.png"
            />
          </div>
          <div className={styles.text19}>
            <div className={styles.text20}>Modified A product in Page X</div>
            <div className={styles.text21}>Today, 11:59 AM</div>
          </div>
        </div>
        <div className={styles.iconText8}>
          <div className={styles.iconSet8}>
            <img
              className={styles.male11Icon}
              loading="lazy"
              alt=""
              src="/male11@2x.png"
            />
          </div>
          <div className={styles.text22}>
            <div className={styles.text23}>Deleted a product in Project X</div>
            <div className={styles.text24}>Feb 2, 2023</div>
          </div>
        </div>
        <div className={styles.strip}>
          <div className={styles.expressionParser} />
          <div className={styles.expressionParser1} />
          <div className={styles.expressionParser2} />
          <div className={styles.expressionParser3} />
        </div>
      </div>
      <div className={styles.patternFinder}>
        <div className={styles.text25}>
          <div className={styles.eventEmitter}>Followers</div>
        </div>
        <div className={styles.nameBadge}>
          <div className={styles.iconText9}>
            <div className={styles.iconSet9}>
              <img
                className={styles.female15Icon}
                loading="lazy"
                alt=""
                src="/female15@2x.png"
              />
            </div>
            <div className={styles.text26}>
              <div className={styles.treeTraverser}>Natali Craig</div>
            </div>
          </div>
        </div>
        <div className={styles.nameBadge1}>
          <div className={styles.iconText10}>
            <div className={styles.iconSet10}>
              <img
                className={styles.male08Icon}
                loading="lazy"
                alt=""
                src="/male08@2x.png"
              />
            </div>
            <div className={styles.text27}>
              <div className={styles.text28}>Drew Cano</div>
            </div>
          </div>
        </div>
        <div className={styles.nameBadge2}>
          <div className={styles.iconText11}>
            <div className={styles.iconSet11}>
              <img
                className={styles.male06Icon}
                loading="lazy"
                alt=""
                src="/male06@2x.png"
              />
            </div>
            <div className={styles.text29}>
              <div className={styles.text30}>Orlando Diggs</div>
            </div>
          </div>
        </div>
        <div className={styles.nameBadge3}>
          <div className={styles.iconText12}>
            <div className={styles.iconSet12}>
              <img
                className={styles.female08Icon}
                loading="lazy"
                alt=""
                src="/female08@2x.png"
              />
            </div>
            <div className={styles.text31}>
              <div className={styles.text32}>Andi Lane</div>
            </div>
          </div>
        </div>
        <div className={styles.nameBadge4}>
          <div className={styles.iconText13}>
            <div className={styles.iconSet13}>
              <img
                className={styles.female09Icon}
                loading="lazy"
                alt=""
                src="/female09@2x.png"
              />
            </div>
            <div className={styles.text33}>
              <div className={styles.text34}>Kate Morrison</div>
            </div>
          </div>
        </div>
        <div className={styles.nameBadge5}>
          <div className={styles.iconText14}>
            <div className={styles.iconSet14}>
              <img
                className={styles.d03Icon}
                loading="lazy"
                alt=""
                src="/3d03@2x.png"
              />
            </div>
            <div className={styles.text35}>
              <div className={styles.text36}>Koray Okumus</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RightBar;
