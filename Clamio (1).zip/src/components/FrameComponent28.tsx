import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./FrameComponent28.module.css";

const FrameComponent28: FunctionComponent = () => {
  const navigate = useNavigate();

  const onFrameContainerClick = useCallback(() => {
    navigate("/creator-login");
  }, [navigate]);

  return (
    <section className={styles.clamioRewardsProgramParent}>
      <h1 className={styles.clamioRewardsProgramContainer}>
        <span className={styles.clamio}>CLAMIO</span>
        <span className={styles.rewardsProgram}> Rewards Program</span>
      </h1>
      <div className={styles.rectangleParent}>
        <div className={styles.frameChild} />
        <div className={styles.frameItem} />
        <header className={styles.frameWrapper}>
          <div className={styles.createAndSellParent}>
            <b className={styles.createAndSell}>Create and Sell</b>
            <nav className={styles.frameContainer}>
              <nav className={styles.frameParent}>
                <div className={styles.communiityWrapper}>
                  <b className={styles.communiity}>COMMUNIITY</b>
                </div>
                <b className={styles.explore}>Explore</b>
                <div className={styles.creatorsWrapper}>
                  <b className={styles.creators}>Creators</b>
                </div>
                <b className={styles.join}>Join</b>
              </nav>
            </nav>
          </div>
        </header>
        <div className={styles.frameGroup}>
          <div className={styles.frameDiv}>
            <div className={styles.frameParent1}>
              <div className={styles.referClamioToFellowCreatorParent}>
                <div className={styles.referClamioToContainer}>
                  <p
                    className={styles.referClamioTo}
                  >{`Refer CLAMIO to fellow creators or sell 100 Digital Products through CLAMIO, `}</p>
                  <p className={styles.p}>{`&`}</p>
                  <p className={styles.earnRs50000}>earn Rs. 50000*</p>
                </div>
                <div className={styles.frameWrapper1}>
                  <div
                    className={styles.frameWrapper2}
                    onClick={onFrameContainerClick}
                  >
                    <button className={styles.rectangleGroup}>
                      <div className={styles.frameInner} />
                      <b className={styles.viewDashboard}>View Dashboard</b>
                    </button>
                  </div>
                </div>
              </div>
              <div className={styles.termsAndConditionsApplyWrapper}>
                <div className={styles.termsAndConditions}>
                  *Terms and conditions Apply
                </div>
              </div>
            </div>
          </div>
          <img
            className={styles.piyd9y533RemovebgPreview1Icon}
            loading="lazy"
            alt=""
            src="/522835piyd9y533removebgpreview-1@2x.png"
          />
        </div>
      </div>
    </section>
  );
};

export default FrameComponent28;
