import { FunctionComponent, useMemo, type CSSProperties } from "react";
import styles from "./FrameComponent15.module.css";

export type FrameComponent15Type = {
  /** Style props */
  propFlex?: CSSProperties["flex"];
  propMinWidth?: CSSProperties["minWidth"];
  propAlignSelf?: CSSProperties["alignSelf"];
};

const FrameComponent15: FunctionComponent<FrameComponent15Type> = ({
  propFlex,
  propMinWidth,
  propAlignSelf,
}) => {
  const frameDiv3Style: CSSProperties = useMemo(() => {
    return {
      flex: propFlex,
      minWidth: propMinWidth,
      alignSelf: propAlignSelf,
    };
  }, [propFlex, propMinWidth, propAlignSelf]);

  return (
    <div className={styles.frameParent} style={frameDiv3Style}>
      <div className={styles.ellipseWrapper}>
        <div className={styles.frameChild} />
      </div>
      <div className={styles.frameGroup}>
        <div className={styles.frameWrapper}>
          <img
            className={styles.frameItem}
            loading="lazy"
            alt=""
            src="/frame-90.svg"
          />
        </div>
        <div
          className={styles.loremIpsumDolor}
        >{`Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. `}</div>
      </div>
    </div>
  );
};

export default FrameComponent15;
