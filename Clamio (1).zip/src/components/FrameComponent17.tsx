import { FunctionComponent, useMemo, type CSSProperties } from "react";
import styles from "./FrameComponent17.module.css";

export type FrameComponent17Type = {
  easyToUse?: string;

  /** Style props */
  propPadding?: CSSProperties["padding"];
  propAlignSelf?: CSSProperties["alignSelf"];
};

const FrameComponent17: FunctionComponent<FrameComponent17Type> = ({
  easyToUse,
  propPadding,
  propAlignSelf,
}) => {
  const frameDiv2Style: CSSProperties = useMemo(() => {
    return {
      padding: propPadding,
      alignSelf: propAlignSelf,
    };
  }, [propPadding, propAlignSelf]);

  return (
    <div className={styles.frameParent}>
      <div className={styles.starWrapper} style={frameDiv2Style}>
        <img
          className={styles.frameChild}
          loading="lazy"
          alt=""
          src="/star-4.svg"
        />
      </div>
      <div className={styles.easyToUse}>{easyToUse}</div>
    </div>
  );
};

export default FrameComponent17;
