import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import FrameComponent1 from "./FrameComponent1";
import styles from "./FrameComponent.module.css";

const FrameComponent: FunctionComponent = () => {
  const navigate = useNavigate();

  const onButtonClick = useCallback(() => {
    navigate("/product");
  }, [navigate]);

  const onButton1Click = useCallback(() => {
    // Please sync "Discover Creator" to the project
  }, []);

  return (
    <section className={styles.loopTable}>
      <div className={styles.variableTable}>
        <div className={styles.errorTable}>
          <h1 className={styles.getInspired}>Get Inspired</h1>
          <div className={styles.returnPoint}>
            <div className={styles.dontMissOut}>
              Don’t miss out on fresh content and follow your favorite creators
              today! Stay in the loop and never miss their newest creations.
            </div>
          </div>
        </div>
        <FrameComponent1
          onButton5Click={onButtonClick}
          onButton6Click={onButton1Click}
        />
      </div>
    </section>
  );
};

export default FrameComponent;
