import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./FrameComponent10.module.css";

const FrameComponent10: FunctionComponent = () => {
  const navigate = useNavigate();

  const onFrameContainerClick = useCallback(() => {
    const anchor = document.querySelector("[data-scroll-to='rectangle']");
    if (anchor) {
      anchor.scrollIntoView({ block: "start", behavior: "smooth" });
    }
  }, []);

  const onFrameContainer1Click = useCallback(() => {
    // Please sync " Listing" to the project
  }, []);

  const onFrameContainer2Click = useCallback(() => {
    navigate("/analytics");
  }, [navigate]);

  const onFrameContainer3Click = useCallback(() => {
    // Please sync "Payouts" to the project
  }, []);

  const onFrameContainer4Click = useCallback(() => {
    navigate("/usercreator-community");
  }, [navigate]);

  const onFrameContainer6Click = useCallback(() => {
    // Please sync "Followers" to the project
  }, []);

  const onFrameContainer7Click = useCallback(() => {
    navigate("/rewards");
  }, [navigate]);

  return (
    <nav className={styles.frameParent}>
      <div className={styles.frameGroup} onClick={onFrameContainerClick}>
        <img
          className={styles.frameChild}
          loading="lazy"
          alt=""
          src="/group-1.svg"
        />
        <div className={styles.homeWrapper}>
          <b className={styles.home}>Home</b>
        </div>
      </div>
      <div
        className={styles.gridiconsproductParent}
        onClick={onFrameContainer1Click}
      >
        <img
          className={styles.gridiconsproduct}
          loading="lazy"
          alt=""
          src="/gridiconsproduct.svg"
        />
        <div className={styles.productWrapper}>
          <b className={styles.product}>Product</b>
        </div>
      </div>
      <div
        className={styles.carbonanalyticsParent}
        onClick={onFrameContainer2Click}
      >
        <img
          className={styles.carbonanalyticsIcon}
          loading="lazy"
          alt=""
          src="/carbonanalytics.svg"
        />
        <b className={styles.analytics}>Analytics</b>
      </div>
      <div className={styles.jamcoinFParent} onClick={onFrameContainer3Click}>
        <img
          className={styles.jamcoinFIcon}
          loading="lazy"
          alt=""
          src="/jamcoinf.svg"
        />
        <b className={styles.payouts}>Payouts</b>
      </div>
      <div
        className={styles.fluentpeopleCommunity24FilParent}
        onClick={onFrameContainer4Click}
      >
        <img
          className={styles.fluentpeopleCommunity24FilIcon}
          loading="lazy"
          alt=""
          src="/fluentpeoplecommunity24filled.svg"
        />
        <div className={styles.communityWrapper}>
          <b className={styles.community}>Community</b>
        </div>
      </div>
      <div className={styles.materialSymbolsdashboardParent}>
        <img
          className={styles.materialSymbolsdashboardIcon}
          loading="lazy"
          alt=""
          src="/materialsymbolsdashboard.svg"
        />
        <div className={styles.dashboardWrapper}>
          <b className={styles.dashboard}>Dashboard</b>
        </div>
      </div>
      <div
        className={styles.gameIconsshadowFollowerParent}
        onClick={onFrameContainer6Click}
      >
        <img
          className={styles.gameIconsshadowFollower}
          loading="lazy"
          alt=""
          src="/gameiconsshadowfollower.svg"
        />
        <div className={styles.folllowersWrapper}>
          <b className={styles.folllowers}>Folllowers</b>
        </div>
      </div>
      <div
        className={styles.arcticonsrewardsParent}
        onClick={onFrameContainer7Click}
      >
        <img
          className={styles.arcticonsrewards}
          loading="lazy"
          alt=""
          src="/arcticonsrewards.svg"
        />
        <div className={styles.rewardsWrapper}>
          <b className={styles.rewards}>Rewards</b>
        </div>
      </div>
      <div className={styles.uilsettingParent}>
        <img
          className={styles.uilsettingIcon}
          loading="lazy"
          alt=""
          src="/uilsetting.svg"
        />
        <div className={styles.settingsWrapper}>
          <b className={styles.settings}>Settings</b>
        </div>
      </div>
      <div className={styles.materialSymbolssupportParent}>
        <img
          className={styles.materialSymbolssupportIcon}
          loading="lazy"
          alt=""
          src="/materialsymbolssupport.svg"
        />
        <div className={styles.supportWrapper}>
          <b className={styles.support}>Support</b>
        </div>
      </div>
    </nav>
  );
};

export default FrameComponent10;
