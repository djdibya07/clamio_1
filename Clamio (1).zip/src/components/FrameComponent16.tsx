import { FunctionComponent } from "react";
import FrameComponent17 from "./FrameComponent17";
import styles from "./FrameComponent16.module.css";

const FrameComponent16: FunctionComponent = () => {
  return (
    <div className={styles.starParent}>
      <img className={styles.frameChild} alt="" />
      <div className={styles.frameItem} />
      <div className={styles.productHighlightsWrapper}>
        <h3 className={styles.productHighlights}>Product Highlights</h3>
      </div>
      <div className={styles.frameParent}>
        <FrameComponent17 easyToUse="Easy to use" />
        <FrameComponent17
          easyToUse="Easy Returns"
          propPadding="0px var(--padding-53xl)"
          propAlignSelf="stretch"
        />
        <FrameComponent17
          easyToUse="Result in 10 days"
          propPadding="0px var(--padding-53xl)"
          propAlignSelf="stretch"
        />
        <FrameComponent17
          easyToUse="Google certified"
          propPadding="0px var(--padding-53xl)"
          propAlignSelf="stretch"
        />
      </div>
    </div>
  );
};

export default FrameComponent16;
