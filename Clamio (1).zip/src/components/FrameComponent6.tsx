import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import FrameComponent1 from "./FrameComponent1";
import styles from "./FrameComponent6.module.css";

const FrameComponent6: FunctionComponent = () => {
  const navigate = useNavigate();

  const onFrameButtonClick = useCallback(() => {
    navigate("/product");
  }, [navigate]);

  return (
    <div className={styles.frameWrapper}>
      <div className={styles.frameParent}>
        <div className={styles.frameGroup}>
          <div className={styles.getInspiredParent}>
            <h1 className={styles.getInspired}>Get Inspired</h1>
            <img
              className={styles.b4ff0c68d07443f74cb851462d4870Icon}
              loading="lazy"
              alt=""
              src="/b4ff0c68d07443f74cb851462d487042removebgpreview-1@2x.png"
            />
          </div>
          <div className={styles.dontMissOutOnFreshContenWrapper}>
            <div className={styles.dontMissOut}>
              Don’t miss out on fresh content and follow your favorite creators
              today! Stay in the loop and never miss their newest creations.
            </div>
          </div>
        </div>
        <FrameComponent1
          onButton5Click={onFrameButtonClick}
          browseProductsDisplay="inline-block"
          discoverCreatorsDisplay="inline-block"
        />
      </div>
    </div>
  );
};

export default FrameComponent6;
