import { FunctionComponent } from "react";
import styles from "./FrameComponent2.module.css";

const FrameComponent2: FunctionComponent = () => {
  return (
    <section className={styles.controlFlow}>
      <div className={styles.dataProcess}>
        <h1 className={styles.faqs}>FAQs</h1>
        <div className={styles.dataTransfer}>
          <div className={styles.dataStore}>
            <h2 className={styles.canIAdd}>
              Can I add wide range of products?
            </h2>
            <div className={styles.absolutelyOurPlatform}>
              Absolutely! Our platform allows you to easily add wide range of
              products from your catalog.
            </div>
          </div>
          <div className={styles.dataStore1}>
            <h2 className={styles.whatKindOf}>
              What kind of digital products can I sell?
            </h2>
            <div className={styles.youCanSell}>
              You can sell a wide range of digital products like ebooks,
              software, videos, music, and more.
            </div>
          </div>
        </div>
      </div>
      <img
        className={styles.b4ff0c68d07443f74cb851462d4870Icon}
        loading="lazy"
        alt=""
        src="/b4ff0c68d07443f74cb851462d487042removebgpreview-1@2x.png"
      />
    </section>
  );
};

export default FrameComponent2;
