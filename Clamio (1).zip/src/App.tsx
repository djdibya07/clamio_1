import { useEffect } from "react";
import {
  Routes,
  Route,
  useNavigationType,
  useLocation,
} from "react-router-dom";
import Explore from "./pages/Explore";
import ExploreAfterLogin from "./pages/ExploreAfterLogin";
import Analytics from "./pages/Analytics";
import CreatorLogin from "./pages/CreatorLogin";
import CreateProductPage from "./pages/CreateProductPage";
import UserProductDetail from "./pages/UserProductDetail";
import Product from "./pages/Product";
import UserCreatorCommunity from "./pages/UserCreatorCommunity";
import Rewards from "./pages/Rewards";
import ProductDetailsAndListing from "./pages/ProductDetailsAndListing";

function App() {
  const action = useNavigationType();
  const location = useLocation();
  const pathname = location.pathname;

  useEffect(() => {
    if (action !== "POP") {
      window.scrollTo(0, 0);
    }
  }, [action, pathname]);

  useEffect(() => {
    let title = "";
    let metaDescription = "";

    switch (pathname) {
      case "/":
        title = "";
        metaDescription = "";
        break;
      case "/explore-after-login":
        title = "";
        metaDescription = "";
        break;
      case "/analytics":
        title = "";
        metaDescription = "";
        break;
      case "/creator-login":
        title = "";
        metaDescription = "";
        break;
      case "/create-product-page":
        title = "";
        metaDescription = "";
        break;
      case "/user-product-detail":
        title = "";
        metaDescription = "";
        break;
      case "/product":
        title = "";
        metaDescription = "";
        break;
      case "/usercreator-community":
        title = "";
        metaDescription = "";
        break;
      case "/rewards":
        title = "";
        metaDescription = "";
        break;
      case "/product-details-and-listing":
        title = "";
        metaDescription = "";
        break;
    }

    if (title) {
      document.title = title;
    }

    if (metaDescription) {
      const metaDescriptionTag: HTMLMetaElement | null = document.querySelector(
        'head > meta[name="description"]'
      );
      if (metaDescriptionTag) {
        metaDescriptionTag.content = metaDescription;
      }
    }
  }, [pathname]);

  return (
    <Routes>
      <Route path="/" element={<Explore />} />
      <Route path="/explore-after-login" element={<ExploreAfterLogin />} />
      <Route path="/analytics" element={<Analytics />} />
      <Route path="/creator-login" element={<CreatorLogin />} />
      <Route path="/create-product-page" element={<CreateProductPage />} />
      <Route path="/user-product-detail" element={<UserProductDetail />} />
      <Route path="/product" element={<Product />} />
      <Route path="/usercreator-community" element={<UserCreatorCommunity />} />
      <Route path="/rewards" element={<Rewards />} />
      <Route
        path="/product-details-and-listing"
        element={<ProductDetailsAndListing />}
      />
    </Routes>
  );
}
export default App;
