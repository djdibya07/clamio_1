import { FunctionComponent } from "react";
import FrameComponent5 from "../components/FrameComponent5";
import FrameComponent4 from "../components/FrameComponent4";
import InstanceInstigator from "../components/InstanceInstigator";
import FrameComponent3 from "../components/FrameComponent3";
import FrameComponent2 from "../components/FrameComponent2";
import FrameComponent from "../components/FrameComponent";
import styles from "./Explore.module.css";

const Explore: FunctionComponent = () => {
  return (
    <div className={styles.explore}>
      <FrameComponent5 />
      <section className={styles.frameParent}>
        <div className={styles.frameGroup}>
          <FrameComponent4 />
          <InstanceInstigator />
        </div>
        <FrameComponent3 />
      </section>
      <img className={styles.vectorIcon} alt="" src="/vector22.svg" />
      <img className={styles.vectorIcon1} alt="" src="/vector23.svg" />
      <img className={styles.vectorIcon2} alt="" src="/vector24.svg" />
      <img className={styles.vectorIcon3} alt="" src="/vector25.svg" />
      <img className={styles.vectorIcon4} alt="" src="/vector26.svg" />
      <img className={styles.vectorIcon5} alt="" src="/vector27.svg" />
      <img className={styles.vectorIcon6} alt="" src="/vector28.svg" />
      <img className={styles.vectorIcon7} alt="" src="/vector29.svg" />
      <img className={styles.vectorIcon8} alt="" src="/vector30.svg" />
      <img className={styles.vectorIcon9} alt="" src="/vector26.svg" />
      <img className={styles.vectorIcon10} alt="" src="/vector31.svg" />
      <img className={styles.vectorIcon11} alt="" src="/vector32.svg" />
      <img className={styles.vectorIcon12} alt="" src="/vector33.svg" />
      <img className={styles.vectorIcon13} alt="" src="/vector34.svg" />
      <img className={styles.vectorIcon14} alt="" src="/vector35.svg" />
      <img className={styles.vectorIcon15} alt="" src="/vector36.svg" />
      <img className={styles.vectorIcon16} alt="" src="/vector37.svg" />
      <img className={styles.vectorIcon17} alt="" src="/vector38.svg" />
      <img className={styles.vectorIcon18} alt="" src="/vector39.svg" />
      <FrameComponent2 />
      <FrameComponent />
    </div>
  );
};

export default Explore;
