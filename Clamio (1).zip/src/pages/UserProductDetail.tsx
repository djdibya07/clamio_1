import { FunctionComponent } from "react";
import FrameComponent18 from "../components/FrameComponent18";
import FrameComponent16 from "../components/FrameComponent16";
import FrameComponent14 from "../components/FrameComponent14";
import ParentWithChildrenStar from "../components/ParentWithChildrenStar";
import styles from "./UserProductDetail.module.css";

const UserProductDetail: FunctionComponent = () => {
  return (
    <div className={styles.userProductDetail}>
      <div className={styles.userProductDetailChild} />
      <FrameComponent18 />
      <div className={styles.userProductDetailItem} />
      <section className={styles.frameParent}>
        <FrameComponent16 />
        <FrameComponent14 />
        <h3 className={styles.exploreSimilarProducts}>
          Explore Similar Products
        </h3>
      </section>
      <div className={styles.beverageAnimationCartAnim}>
        <ParentWithChildrenStar />
        <ParentWithChildrenStar
          propAlignSelf="stretch"
          propWidth="287px"
          propFlex="unset"
          propMinWidth="unset"
          propFlex1="1"
          propHeight="unset"
        />
        <ParentWithChildrenStar
          propAlignSelf="stretch"
          propWidth="287px"
          propFlex="unset"
          propMinWidth="unset"
          propFlex1="1"
          propHeight="unset"
        />
        <ParentWithChildrenStar
          propAlignSelf="stretch"
          propWidth="287px"
          propFlex="unset"
          propMinWidth="unset"
          propFlex1="1"
          propHeight="unset"
        />
      </div>
    </div>
  );
};

export default UserProductDetail;
