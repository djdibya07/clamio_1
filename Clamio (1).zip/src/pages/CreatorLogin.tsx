import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import Frame from "../components/Frame";
import FrameComponent10 from "../components/FrameComponent10";
import FrameComponent9 from "../components/FrameComponent9";
import styles from "./CreatorLogin.module.css";

const CreatorLogin: FunctionComponent = () => {
  const navigate = useNavigate();

  const onReferAndEarnClick = useCallback(() => {
    navigate("/rewards");
  }, [navigate]);

  const onGoToExploreClick = useCallback(() => {
    navigate("/explore-after-login");
  }, [navigate]);

  return (
    <div className={styles.creatorLogin}>
      <b className={styles.referAndEarn} onClick={onReferAndEarnClick}>
        Refer and Earn
      </b>
      <b
        className={styles.goToExplore}
        onClick={onGoToExploreClick}
      >{`Go to Explore `}</b>
      <h1 className={styles.analytics}>Analytics</h1>
      <h1 className={styles.products}>
        <ul className={styles.products1}>
          <li>Products</li>
        </ul>
      </h1>
      <h1 className={styles.referral}>
        <ul className={styles.referral1}>
          <li>Referral</li>
        </ul>
      </h1>
      <h1 className={styles.likedPosts}>
        <ul className={styles.likedPosts1}>
          <li>Liked Posts</li>
        </ul>
      </h1>
      <h1 className={styles.community}>
        <ul className={styles.community1}>
          <li>Community</li>
        </ul>
      </h1>
      <h1 className={styles.emails}>
        <ul className={styles.emails1}>
          <li>Emails</li>
        </ul>
      </h1>
      <h1 className={styles.topFans}>
        <ul className={styles.topFans1}>
          <li>Top Fans</li>
        </ul>
      </h1>
      <h1 className={styles.firstSale}>
        <ul className={styles.firstSale1}>
          <li>First Sale</li>
        </ul>
      </h1>
      <h1 className={styles.payout}>
        <ul className={styles.payout1}>
          <li>Payout</li>
        </ul>
      </h1>
      <h1 className={styles.activity}>Activity</h1>
      <div className={styles.block}>
        <div className={styles.group}>
          <div className={styles.tap}>
            <div className={styles.text}>
              <div className={styles.text1}>Total Users</div>
            </div>
          </div>
          <div className={styles.tap1}>
            <div className={styles.text2}>
              <div className={styles.text3}>Total Projects</div>
            </div>
          </div>
          <div className={styles.tap2}>
            <div className={styles.text4}>
              <div className={styles.text5}>Operating Status</div>
            </div>
          </div>
          <div className={styles.text6}>
            <div className={styles.text7}>|</div>
          </div>
          <div className={styles.tag}>
            <input className={styles.dot} checked={true} type="radio" />
            <div className={styles.tag1}>Current Week</div>
          </div>
          <div className={styles.tag2}>
            <input className={styles.dot1} checked={true} type="radio" />
            <div className={styles.tag3}>Previous Week</div>
          </div>
        </div>
        <div className={styles.chart}>
          <div className={styles.leftText}>
            <div className={styles.div}>30M</div>
            <div className={styles.div1}>20M</div>
            <div className={styles.div2}>10M</div>
            <div className={styles.div3}>0</div>
          </div>
          <Frame />
        </div>
      </div>
      <b className={styles.userName}>User Name</b>
      <main className={styles.zondiconsnotificationParent}>
        <img
          className={styles.zondiconsnotification}
          alt=""
          src="/zondiconsnotification.svg"
        />
        <img
          className={styles.frameChild}
          loading="lazy"
          alt=""
          src="/vector-710.svg"
        />
        <img className={styles.frameItem} alt="" src="/vector-88.svg" />
        <div className={styles.frameInner} />
        <img
          className={styles.gridiconsdropdown}
          loading="lazy"
          alt=""
          src="/gridiconsdropdown.svg"
        />
      </main>
      <FrameComponent10 />
      <h1 className={styles.itsTimeTo}>It’s time to create something new</h1>
      <FrameComponent9 />
    </div>
  );
};

export default CreatorLogin;
