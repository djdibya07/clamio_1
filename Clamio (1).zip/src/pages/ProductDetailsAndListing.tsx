import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import FrameComponent30 from "../components/FrameComponent30";
import FrameComponent29 from "../components/FrameComponent29";
import styles from "./ProductDetailsAndListing.module.css";

const ProductDetailsAndListing: FunctionComponent = () => {
  const navigate = useNavigate();

  const onFrameContainerClick = useCallback(() => {
    const anchor = document.querySelector(
      "[data-scroll-to='rectangleTextarea']"
    );
    if (anchor) {
      anchor.scrollIntoView({ block: "start", behavior: "smooth" });
    }
  }, []);

  const onEditIconClick = useCallback(() => {
    navigate("/create-product-page");
  }, [navigate]);

  const onFrameContainer1Click = useCallback(() => {
    const anchor = document.querySelector(
      "[data-scroll-to='rectangleTextarea']"
    );
    if (anchor) {
      anchor.scrollIntoView({ block: "start", behavior: "smooth" });
    }
  }, []);

  const onEditIcon2Click = useCallback(() => {
    navigate("/create-product-page");
  }, [navigate]);

  const onFrameContainer2Click = useCallback(() => {
    const anchor = document.querySelector(
      "[data-scroll-to='rectangleTextarea']"
    );
    if (anchor) {
      anchor.scrollIntoView({ block: "start", behavior: "smooth" });
    }
  }, []);

  const onEditIcon3Click = useCallback(() => {
    navigate("/create-product-page");
  }, [navigate]);

  const onFrameContainer3Click = useCallback(() => {
    navigate("/creator-login");
  }, [navigate]);

  const onShareCreativityAreaClick = useCallback(() => {
    navigate("/analytics");
  }, [navigate]);

  const onFrameContainer12Click = useCallback(() => {
    navigate("/usercreator-community");
  }, [navigate]);

  const onFrameContainer22Click = useCallback(() => {
    navigate("/rewards");
  }, [navigate]);

  const onFrameContainer32Click = useCallback(() => {
    // Please sync " Listing" to the project
  }, []);

  const onFrameButtonClick = useCallback(() => {
    navigate("/create-product-page");
  }, [navigate]);

  const onCarbonanalyticsIcon1Click = useCallback(() => {
    navigate("/analytics");
  }, [navigate]);

  const onGoToExploreClick = useCallback(() => {
    navigate("/explore-after-login");
  }, [navigate]);

  return (
    <div className={styles.productDetailsAndListing}>
      <b className={styles.referAndEarn}>Refer and Earn</b>
      <div className={styles.frameParent} onClick={onFrameContainer3Click}>
        <img
          className={styles.frameChild}
          loading="lazy"
          alt=""
          src="/group-1.svg"
        />
        <div className={styles.homeWrapper}>
          <b className={styles.home}>Home</b>
        </div>
      </div>
      <div
        className={styles.shareCreativityArea}
        onClick={onShareCreativityAreaClick}
      >
        <img
          className={styles.carbonanalyticsIcon}
          loading="lazy"
          alt=""
          src="/carbonanalytics.svg"
        />
        <b className={styles.analytics}>Analytics</b>
      </div>
      <b className={styles.payouts}>Payouts</b>
      <div
        className={styles.fluentpeopleCommunity24FilParent}
        onClick={onFrameContainer12Click}
      >
        <img
          className={styles.fluentpeopleCommunity24FilIcon}
          loading="lazy"
          alt=""
          src="/fluentpeoplecommunity24filled.svg"
        />
        <div className={styles.communityWrapper}>
          <b className={styles.community}>Community</b>
        </div>
      </div>
      <b className={styles.dashboard}>Dashboard</b>
      <b className={styles.folllowers}>Folllowers</b>
      <div
        className={styles.arcticonsrewardsParent}
        onClick={onFrameContainer22Click}
      >
        <img
          className={styles.arcticonsrewards}
          loading="lazy"
          alt=""
          src="/arcticonsrewards.svg"
        />
        <div className={styles.rewardsWrapper}>
          <b className={styles.rewards}>Rewards</b>
        </div>
      </div>
      <b className={styles.settings}>Settings</b>
      <b className={styles.support}>Support</b>
      <b className={styles.userName}>User Name</b>
      <div
        className={styles.gridiconsproductParent}
        onClick={onFrameContainer32Click}
      >
        <img
          className={styles.gridiconsproduct}
          loading="lazy"
          alt=""
          src="/gridiconsproduct.svg"
        />
        <div className={styles.productWrapper}>
          <b className={styles.product}>Product</b>
        </div>
      </div>
      <h1 className={styles.shareYourCreativity}>Share your Creativity:</h1>
      <FrameComponent30 />
      <h1 className={styles.productListing}>Product Listing:</h1>
      <div className={styles.frameGroup}>
        <FrameComponent29
          productA="Product A"
          onFrameContainer5Click={onFrameContainerClick}
          onEditIconClick={onEditIconClick}
        />
        <FrameComponent29
          productA="Product B"
          onFrameContainer5Click={onFrameContainer1Click}
          onEditIconClick={onEditIcon2Click}
        />
        <FrameComponent29
          productA="Product C"
          onFrameContainer5Click={onFrameContainer2Click}
          onEditIconClick={onEditIcon3Click}
        />
        <FrameComponent29 productA="Product D" />
        <FrameComponent29 productA="Product E" />
        <FrameComponent29 productA="Product F" />
      </div>
      <div className={styles.rectangleParent}>
        <div className={styles.frameItem} />
        <input
          className={styles.httpsproduct1}
          placeholder="https://product1"
          type="text"
        />
      </div>
      <h1 className={styles.productA}>Product A</h1>
      <div className={styles.details}>Details:</div>
      <div className={styles.loremIpsumDolor}>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
        veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
        commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
        velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint
        occaecat cupidatat non proident, sunt in culpa qui officia deserunt
        mollit anim id est laborum.
      </div>
      <div className={styles.rs25}>Rs.25</div>
      <button className={styles.rectangleGroup} onClick={onFrameButtonClick}>
        <div className={styles.frameInner} />
        <b className={styles.edit}>Edit</b>
      </button>
      <main className={styles.zondiconsnotificationParent}>
        <img
          className={styles.zondiconsnotification}
          alt=""
          src="/zondiconsnotification.svg"
        />
        <img
          className={styles.jamcoinFIcon}
          loading="lazy"
          alt=""
          src="/jamcoinf.svg"
        />
        <img
          className={styles.materialSymbolsdashboardIcon}
          loading="lazy"
          alt=""
          src="/materialsymbolsdashboard.svg"
        />
        <img
          className={styles.gameIconsshadowFollower}
          loading="lazy"
          alt=""
          src="/gameiconsshadowfollower.svg"
        />
        <img
          className={styles.uilsettingIcon}
          loading="lazy"
          alt=""
          src="/uilsetting.svg"
        />
        <img
          className={styles.materialSymbolssupportIcon}
          loading="lazy"
          alt=""
          src="/materialsymbolssupport.svg"
        />
        <img
          className={styles.vectorIcon}
          loading="lazy"
          alt=""
          src="/vector-712.svg"
        />
        <img className={styles.frameChild1} alt="" src="/vector-88.svg" />
        <div className={styles.ellipseDiv} />
        <img
          className={styles.gridiconsdropdown}
          loading="lazy"
          alt=""
          src="/gridiconsdropdown.svg"
        />
        <img
          className={styles.copyIcon}
          loading="lazy"
          alt=""
          src="/copy.svg"
        />
        <img
          className={styles.logosfacebookIcon}
          loading="lazy"
          alt=""
          src="/logosfacebook.svg"
        />
        <img
          className={styles.logoswhatsappIcon}
          loading="lazy"
          alt=""
          src="/logoswhatsappicon.svg"
        />
        <img
          className={styles.skillIconsinstagram}
          loading="lazy"
          alt=""
          src="/skilliconsinstagram.svg"
        />
        <img
          className={styles.carbonanalyticsIcon1}
          loading="lazy"
          alt=""
          src="/carbonanalytics-1.svg"
          onClick={onCarbonanalyticsIcon1Click}
        />
      </main>
      <div className={styles.productDetailsAndListingInner}>
        <div className={styles.rectangleContainer}>
          <textarea className={styles.rectangleTextarea} rows={14} cols={15} />
          <textarea className={styles.frameChild2} rows={14} cols={15} />
          <textarea
            className={styles.frameChild3}
            rows={16}
            cols={17}
            data-scroll-to="rectangleTextarea"
          />
        </div>
      </div>
      <b
        className={styles.goToExplore}
        onClick={onGoToExploreClick}
      >{`Go to Explore `}</b>
    </div>
  );
};

export default ProductDetailsAndListing;
