import { FunctionComponent } from "react";
import FrameComponent28 from "../components/FrameComponent28";
import FrameComponent27 from "../components/FrameComponent27";
import FrameComponent26 from "../components/FrameComponent26";
import FrameComponent25 from "../components/FrameComponent25";
import styles from "./Rewards.module.css";

const Rewards: FunctionComponent = () => {
  return (
    <div className={styles.rewards}>
      <FrameComponent28 />
      <FrameComponent27 />
      <FrameComponent26 />
      <FrameComponent25 />
    </div>
  );
};

export default Rewards;
