import { FunctionComponent, useCallback } from "react";
import Widget from "../components/Widget";
import RightBar from "../components/RightBar";
import { useNavigate } from "react-router-dom";
import styles from "./Analytics.module.css";

const Analytics: FunctionComponent = () => {
  const navigate = useNavigate();

  const onDecisionMakerContainerClick = useCallback(() => {
    navigate("/creator-login");
  }, [navigate]);

  const onDecisionMakerContainer1Click = useCallback(() => {
    const anchor = document.querySelector("[data-scroll-to='userNameText']");
    if (anchor) {
      anchor.scrollIntoView({ block: "start", behavior: "smooth" });
    }
  }, []);

  const onDecisionMakerContainer2Click = useCallback(() => {
    // Please sync "Payouts" to the project
  }, []);

  const onDecisionMakerContainer3Click = useCallback(() => {
    navigate("/usercreator-community");
  }, [navigate]);

  const onDecisionMakerContainer4Click = useCallback(() => {
    // Please sync "Followers" to the project
  }, []);

  const onDecisionMakerContainer5Click = useCallback(() => {
    navigate("/rewards");
  }, [navigate]);

  const onDecisionMakerContainer6Click = useCallback(() => {
    // Please sync " Listing" to the project
  }, []);

  return (
    <div className={styles.analytics}>
      <img className={styles.logicTreeIcon} alt="" src="/logic-tree.svg" />
      <div className={styles.defaultParent}>
        <main className={styles.default}>
          <div className={styles.sidebar}>
            <div className={styles.nameBadge}>
              <div className={styles.iconText}>
                <div className={styles.iconSet}>
                  <img
                    className={styles.byewindIcon}
                    alt=""
                    src="/byewind@2x.png"
                  />
                </div>
                <div className={styles.text}>
                  <div className={styles.text1}>ByeWind</div>
                </div>
              </div>
            </div>
            <div className={styles.frame}>
              <div className={styles.group}>
                <div className={styles.button}>
                  <div className={styles.text2}>
                    <div className={styles.text3}>Favorites</div>
                  </div>
                </div>
                <div className={styles.button1}>
                  <div className={styles.text4}>
                    <div className={styles.text5}>Recently</div>
                  </div>
                </div>
              </div>
              <div className={styles.content}>
                <div className={styles.iconText1}>
                  <div className={styles.iconSet1}>
                    <img className={styles.dotIcon} alt="" src="/dot.svg" />
                  </div>
                  <div className={styles.text6}>
                    <div className={styles.text7}>Overview</div>
                  </div>
                </div>
              </div>
              <div className={styles.content1}>
                <div className={styles.iconText2}>
                  <div className={styles.iconSet2}>
                    <img className={styles.dotIcon1} alt="" src="/dot.svg" />
                  </div>
                  <div className={styles.text8}>
                    <div className={styles.text9}>Projects</div>
                  </div>
                </div>
              </div>
            </div>
            <div className={styles.frame1}>
              <div className={styles.text10}>
                <div className={styles.text11}>Dashboards</div>
              </div>
              <div className={styles.content2}>
                <div className={styles.group1}>
                  <div className={styles.iconSet3}>
                    <img
                      className={styles.selectedIcon}
                      alt=""
                      src="/selected.svg"
                    />
                  </div>
                  <div className={styles.iconSet4}>
                    <img className={styles.arrowlinerightIcon} alt="" />
                  </div>
                </div>
                <div className={styles.iconText3}>
                  <div className={styles.iconSet5}>
                    <img
                      className={styles.chartpiesliceIcon}
                      alt=""
                      src="/chartpieslice.svg"
                    />
                  </div>
                  <div className={styles.text12}>
                    <div className={styles.text13}>Default</div>
                  </div>
                </div>
              </div>
              <div className={styles.content3}>
                <div className={styles.group2}>
                  <div className={styles.iconSet6}>
                    <img className={styles.selectedIcon1} alt="" />
                  </div>
                  <div className={styles.iconSet7}>
                    <img
                      className={styles.arrowlinerightIcon1}
                      alt=""
                      src="/arrowlineright-1.svg"
                    />
                  </div>
                </div>
                <div className={styles.iconText4}>
                  <div className={styles.iconSet8}>
                    <img
                      className={styles.shoppingbagopenIcon}
                      alt=""
                      src="/shoppingbagopen.svg"
                    />
                  </div>
                  <div className={styles.text14}>
                    <div className={styles.text15}>eCommerce</div>
                  </div>
                </div>
              </div>
              <div className={styles.content4}>
                <div className={styles.group3}>
                  <div className={styles.iconSet9}>
                    <img className={styles.selectedIcon2} alt="" />
                  </div>
                  <div className={styles.iconSet10}>
                    <img
                      className={styles.arrowlinerightIcon2}
                      alt=""
                      src="/arrowlineright-1.svg"
                    />
                  </div>
                </div>
                <div className={styles.iconText5}>
                  <div className={styles.iconSet11}>
                    <img
                      className={styles.foldernotchIcon}
                      alt=""
                      src="/foldernotch.svg"
                    />
                  </div>
                  <div className={styles.text16}>
                    <div className={styles.text17}>Projects</div>
                  </div>
                </div>
              </div>
              <div className={styles.content5}>
                <div className={styles.group4}>
                  <div className={styles.iconSet12}>
                    <img className={styles.selectedIcon3} alt="" />
                  </div>
                  <div className={styles.iconSet13}>
                    <img
                      className={styles.arrowlinerightIcon3}
                      alt=""
                      src="/arrowlineright-1.svg"
                    />
                  </div>
                </div>
                <div className={styles.iconText6}>
                  <div className={styles.iconSet14}>
                    <img
                      className={styles.bookopenIcon}
                      alt=""
                      src="/bookopen.svg"
                    />
                  </div>
                  <div className={styles.text18}>
                    <div className={styles.text19}>Online Courses</div>
                  </div>
                </div>
              </div>
            </div>
            <div className={styles.frame2}>
              <div className={styles.text20}>
                <div className={styles.text21}>Pages</div>
              </div>
              <div className={styles.content6}>
                <div className={styles.group5}>
                  <div className={styles.iconSet15}>
                    <img className={styles.selectedIcon4} alt="" />
                  </div>
                  <input className={styles.iconSet16} type="checkbox" />
                </div>
                <div className={styles.iconText7}>
                  <input className={styles.iconSet17} type="checkbox" />
                  <div className={styles.text22}>
                    <div className={styles.text23}>User Profile</div>
                  </div>
                </div>
              </div>
              <div className={styles.content7}>
                <div className={styles.group6}>
                  <div className={styles.iconSet18}>
                    <img className={styles.selectedIcon5} alt="" />
                  </div>
                  <div className={styles.iconSet19}>
                    <img className={styles.arrowlinedownIcon} alt="" />
                  </div>
                </div>
                <div className={styles.iconText8}>
                  <div className={styles.iconSet20}>
                    <img className={styles.identificationbadgeIcon} alt="" />
                  </div>
                  <div className={styles.text24}>
                    <div className={styles.text25}>Overview</div>
                  </div>
                </div>
              </div>
              <div className={styles.content8}>
                <div className={styles.group7}>
                  <div className={styles.iconSet21}>
                    <img className={styles.selectedIcon6} alt="" />
                  </div>
                  <div className={styles.iconSet22}>
                    <img className={styles.arrowlinedownIcon1} alt="" />
                  </div>
                </div>
                <div className={styles.iconText9}>
                  <div className={styles.iconSet23}>
                    <img className={styles.identificationbadgeIcon1} alt="" />
                  </div>
                  <div className={styles.text26}>
                    <div className={styles.text27}>Projects</div>
                  </div>
                </div>
              </div>
              <div className={styles.content9}>
                <div className={styles.group8}>
                  <div className={styles.iconSet24}>
                    <img className={styles.selectedIcon7} alt="" />
                  </div>
                  <div className={styles.iconSet25}>
                    <img className={styles.arrowlinedownIcon2} alt="" />
                  </div>
                </div>
                <div className={styles.iconText10}>
                  <div className={styles.iconSet26}>
                    <img className={styles.identificationbadgeIcon2} alt="" />
                  </div>
                  <div className={styles.text28}>
                    <div className={styles.text29}>Campaigns</div>
                  </div>
                </div>
              </div>
              <div className={styles.content10}>
                <div className={styles.group9}>
                  <div className={styles.iconSet27}>
                    <img className={styles.selectedIcon8} alt="" />
                  </div>
                  <div className={styles.iconSet28}>
                    <img className={styles.arrowlinedownIcon3} alt="" />
                  </div>
                </div>
                <div className={styles.iconText11}>
                  <div className={styles.iconSet29}>
                    <img className={styles.identificationbadgeIcon3} alt="" />
                  </div>
                  <div className={styles.text30}>
                    <div className={styles.text31}>Documents</div>
                  </div>
                </div>
              </div>
              <div className={styles.content11}>
                <div className={styles.group10}>
                  <div className={styles.iconSet30}>
                    <img className={styles.selectedIcon9} alt="" />
                  </div>
                  <div className={styles.iconSet31}>
                    <img className={styles.arrowlinedownIcon4} alt="" />
                  </div>
                </div>
                <div className={styles.iconText12}>
                  <div className={styles.iconSet32}>
                    <img className={styles.identificationbadgeIcon4} alt="" />
                  </div>
                  <div className={styles.text32}>
                    <div className={styles.text33}>Followers</div>
                  </div>
                </div>
              </div>
              <div className={styles.content12}>
                <div className={styles.group11}>
                  <div className={styles.iconSet33}>
                    <img className={styles.selectedIcon10} alt="" />
                  </div>
                  <div className={styles.iconSet34}>
                    <img
                      className={styles.arrowlinerightIcon4}
                      alt=""
                      src="/arrowlineright-1.svg"
                    />
                  </div>
                </div>
                <div className={styles.iconText13}>
                  <div className={styles.iconSet35}>
                    <img
                      className={styles.identificationcardIcon}
                      alt=""
                      src="/identificationcard.svg"
                    />
                  </div>
                  <div className={styles.text34}>
                    <div className={styles.text35}>Account</div>
                  </div>
                </div>
              </div>
              <div className={styles.content13}>
                <div className={styles.group12}>
                  <div className={styles.iconSet36}>
                    <img className={styles.selectedIcon11} alt="" />
                  </div>
                  <div className={styles.iconSet37}>
                    <img
                      className={styles.arrowlinerightIcon5}
                      alt=""
                      src="/arrowlineright-1.svg"
                    />
                  </div>
                </div>
                <div className={styles.iconText14}>
                  <div className={styles.iconSet38}>
                    <img
                      className={styles.usersthreeIcon}
                      alt=""
                      src="/usersthree.svg"
                    />
                  </div>
                  <div className={styles.text36}>
                    <div className={styles.text37}>Corporate</div>
                  </div>
                </div>
              </div>
              <div className={styles.content14}>
                <div className={styles.group13}>
                  <div className={styles.iconSet39}>
                    <img className={styles.selectedIcon12} alt="" />
                  </div>
                  <div className={styles.iconSet40}>
                    <img
                      className={styles.arrowlinerightIcon6}
                      alt=""
                      src="/arrowlineright-1.svg"
                    />
                  </div>
                </div>
                <div className={styles.iconText15}>
                  <div className={styles.iconSet41}>
                    <img
                      className={styles.notebookIcon}
                      alt=""
                      src="/notebook.svg"
                    />
                  </div>
                  <div className={styles.text38}>
                    <div className={styles.text39}>Blog</div>
                  </div>
                </div>
              </div>
              <div className={styles.content15}>
                <div className={styles.group14}>
                  <div className={styles.iconSet42}>
                    <img className={styles.selectedIcon13} alt="" />
                  </div>
                  <div className={styles.iconSet43}>
                    <img
                      className={styles.arrowlinerightIcon7}
                      alt=""
                      src="/arrowlineright-1.svg"
                    />
                  </div>
                </div>
                <div className={styles.iconText16}>
                  <div className={styles.iconSet44}>
                    <img
                      className={styles.chatsteardropIcon}
                      alt=""
                      src="/chatsteardrop.svg"
                    />
                  </div>
                  <div className={styles.text40}>
                    <div className={styles.text41}>Social</div>
                  </div>
                </div>
              </div>
            </div>
            <div className={styles.logo}>
              <div className={styles.snowuiLogo}>
                <img
                  className={styles.snowuiLogoIcon}
                  alt=""
                  src="/snowui-logo.svg"
                />
                <img
                  className={styles.snowuiLogoIcon1}
                  alt=""
                  src="/snowui-logo-1.svg"
                />
              </div>
            </div>
          </div>
          <section className={styles.headerParent}>
            <div className={styles.header}>
              <div className={styles.iconBreadcrumb}>
                <div className={styles.group15}>
                  <div className={styles.button2}>
                    <div className={styles.iconSet45}>
                      <img
                        className={styles.sidebarIcon}
                        alt=""
                        src="/sidebar.svg"
                      />
                    </div>
                  </div>
                  <div className={styles.button3}>
                    <div className={styles.iconSet46}>
                      <img className={styles.starIcon} alt="" src="/star.svg" />
                    </div>
                  </div>
                </div>
                <nav className={styles.breadcrumb}>
                  <div className={styles.button4}>
                    <div className={styles.text42}>
                      <div className={styles.dataMerger}>Dashboards</div>
                    </div>
                  </div>
                  <div className={styles.text43}>
                    <div className={styles.dataSplitter}>/</div>
                  </div>
                  <div className={styles.button5}>
                    <div className={styles.text44}>
                      <div className={styles.text45}>Default</div>
                    </div>
                  </div>
                </nav>
              </div>
              <div className={styles.dataMapper}>
                <div className={styles.search}>
                  <div className={styles.iconText17}>
                    <div className={styles.iconSet47}>
                      <img
                        className={styles.searchIcon}
                        alt=""
                        src="/search.svg"
                      />
                    </div>
                    <div className={styles.text46}>
                      <div className={styles.valueSorter}>Search</div>
                    </div>
                  </div>
                  <input
                    className={styles.text47}
                    placeholder="⌘/"
                    type="text"
                  />
                </div>
                <div className={styles.group16}>
                  <div className={styles.button6}>
                    <div className={styles.iconSet48}>
                      <img
                        className={styles.sunIcon}
                        loading="lazy"
                        alt=""
                        src="/sun.svg"
                      />
                    </div>
                  </div>
                  <div className={styles.button7}>
                    <div className={styles.iconSet49}>
                      <img
                        className={styles.clockcounterclockwiseIcon}
                        loading="lazy"
                        alt=""
                        src="/clockcounterclockwise.svg"
                      />
                    </div>
                  </div>
                  <div className={styles.button8}>
                    <div className={styles.iconSet50}>
                      <img
                        className={styles.bellIcon}
                        loading="lazy"
                        alt=""
                        src="/bell.svg"
                      />
                    </div>
                  </div>
                  <input className={styles.button9} type="checkbox" />
                </div>
              </div>
            </div>
            <div className={styles.frameWrapper}>
              <div className={styles.buttonParent}>
                <div className={styles.button10}>
                  <div className={styles.text48}>
                    <div className={styles.errorCorrector}>Today</div>
                  </div>
                  <div className={styles.iconSet2Wrapper}>
                    <div className={styles.iconSet210}>
                      <img
                        className={styles.arrowlinedownIcon5}
                        alt=""
                        src="/arrowlinedown-6.svg"
                      />
                    </div>
                  </div>
                </div>
                <div className={styles.dataIntegrator}>
                  <Widget
                    logicAnalyzer="Views"
                    valueSequencer="721K"
                    dataAggregator="+11.01%"
                    arrowRise="/arrowrise.svg"
                  />
                  <Widget
                    logicAnalyzer="Visits"
                    valueSequencer="367K"
                    dataAggregator="-0.03%"
                    arrowRise="/arrowfall.svg"
                    propLeft="230px"
                    propBackgroundColor="#e5ecf6"
                    propMinWidth="62px"
                    propMinWidth1="41px"
                  />
                  <Widget
                    logicAnalyzer="New Users"
                    valueSequencer="1,156"
                    dataAggregator="+15.03%"
                    arrowRise="/arrowrise.svg"
                    propLeft="460px"
                    propBackgroundColor="#e3f5ff"
                    propMinWidth="58px"
                    propMinWidth1="49px"
                  />
                  <Widget
                    logicAnalyzer="Active Users"
                    valueSequencer="239K"
                    dataAggregator="+6.08%"
                    arrowRise="/arrowrise.svg"
                    propLeft="690px"
                    propBackgroundColor="#e5ecf6"
                    propMinWidth="63px"
                    propMinWidth1="43px"
                  />
                  <div className={styles.block}>
                    <div className={styles.group17}>
                      <div className={styles.tap}>
                        <div className={styles.text49}>
                          <div className={styles.text50}>Total Users</div>
                        </div>
                      </div>
                      <div className={styles.tap1}>
                        <div className={styles.text51}>
                          <div className={styles.text52}>Total Projects</div>
                        </div>
                      </div>
                      <div className={styles.tap2}>
                        <div className={styles.text53}>
                          <div className={styles.text54}>Operating Status</div>
                        </div>
                      </div>
                      <div className={styles.text55}>
                        <div className={styles.bipartiteGraph}>|</div>
                      </div>
                      <div className={styles.tag}>
                        <input className={styles.dot} type="radio" />
                        <div className={styles.tag1}>Current Week</div>
                      </div>
                      <div className={styles.tag2}>
                        <input className={styles.dot1} type="radio" />
                        <div className={styles.tag3}>Previous Week</div>
                      </div>
                    </div>
                    <div className={styles.chart}>
                      <div className={styles.leftText}>
                        <div className={styles.weightedGraph}>30M</div>
                        <div className={styles.weightedGraph1}>20M</div>
                        <div className={styles.weightedGraph2}>10M</div>
                        <div className={styles.weightedGraph3}>0</div>
                      </div>
                      <div className={styles.adjacencyMatrix}>
                        <div className={styles.line}>
                          <div className={styles.graphTraversal} />
                          <div className={styles.dataFlowControl} />
                          <div className={styles.div} />
                          <div className={styles.div1} />
                        </div>
                        <div className={styles.bottomText}>
                          <div className={styles.div2}>Jan</div>
                          <div className={styles.div3}>Feb</div>
                          <div className={styles.div4}>Mar</div>
                          <div className={styles.wrapper}>
                            <div className={styles.div5}>Apr</div>
                          </div>
                          <div className={styles.div6}>May</div>
                          <div className={styles.container}>
                            <div className={styles.div7}>Jun</div>
                          </div>
                          <div className={styles.div8}>Jul</div>
                        </div>
                        <div className={styles.lineChart01}>
                          <img
                            className={styles.frameIcon}
                            alt=""
                            src="/frame@2x.png"
                          />
                          <div className={styles.frame3}>
                            <button className={styles.toolTips}>
                              <div className={styles.outputProcessor}>
                                3,256,598
                              </div>
                              <div className={styles.c}>⌘C</div>
                            </button>
                            <div className={styles.chartdotWrapper}>
                              <img
                                className={styles.chartdotIcon}
                                alt=""
                                src="/chartdot.svg"
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className={styles.block1}>
                    <div className={styles.text56}>
                      <div className={styles.text57}>Traffic by Website</div>
                    </div>
                    <div className={styles.logicalOperator}>
                      <div className={styles.text58}>
                        <div className={styles.text59}>Google</div>
                        <div className={styles.text60}>YouTube</div>
                        <div className={styles.text61}>Instagram</div>
                        <div className={styles.text62}>Pinterest</div>
                        <div className={styles.text63}>Facebook</div>
                        <div className={styles.text64}>Twitter</div>
                        <div className={styles.text65}>Tumblr</div>
                      </div>
                      <div className={styles.frame4}>
                        <div className={styles.strip}>
                          <div className={styles.rectangle} />
                        </div>
                        <div className={styles.strip1}>
                          <div className={styles.rectangle1} />
                        </div>
                        <div className={styles.strip2}>
                          <div className={styles.rectangle2} />
                        </div>
                        <div className={styles.strip3}>
                          <div className={styles.rectangle3} />
                        </div>
                        <div className={styles.strip4}>
                          <div className={styles.rectangle4} />
                        </div>
                        <div className={styles.strip5}>
                          <div className={styles.rectangle5} />
                        </div>
                        <div className={styles.strip6}>
                          <div className={styles.rectangle6} />
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className={styles.block2}>
                    <div className={styles.text66}>
                      <div className={styles.text67}>Traffic by Device</div>
                    </div>
                    <div className={styles.chart1}>
                      <div className={styles.leftText1}>
                        <div className={styles.logicChecker}>30M</div>
                        <div className={styles.logicChecker1}>20M</div>
                        <div className={styles.valueSplitterX}>10M</div>
                        <div className={styles.dataCompressor}>0</div>
                      </div>
                      <div className={styles.frame5}>
                        <div className={styles.line1}>
                          <div className={styles.outputMerger} />
                          <div className={styles.outputMerger1} />
                          <div className={styles.loopStructure} />
                          <div className={styles.functionContainer} />
                        </div>
                        <div className={styles.bottomText1}>
                          <div className={styles.assignOperator}>Linux</div>
                          <div className={styles.assignOperator1}>Mac</div>
                          <div className={styles.div9}>iOS</div>
                          <div className={styles.stringOperation}>Windows</div>
                          <div className={styles.controlFlow}>Android</div>
                          <div className={styles.errorHandler}>Other</div>
                        </div>
                        <div className={styles.verticalBar}>
                          <div className={styles.div10}>
                            <div className={styles.rectangle7} />
                          </div>
                          <div className={styles.div11}>
                            <div className={styles.rectangle8} />
                          </div>
                          <div className={styles.div12}>
                            <div className={styles.rectangle9} />
                          </div>
                          <div className={styles.div13}>
                            <div className={styles.rectangle10} />
                          </div>
                          <div className={styles.div14}>
                            <div className={styles.rectangle11} />
                          </div>
                          <div className={styles.div15}>
                            <div className={styles.rectangle12} />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className={styles.block3}>
                    <div className={styles.text68}>
                      <div className={styles.text69}>Traffic by Location</div>
                    </div>
                    <div className={styles.frame6}>
                      <img
                        className={styles.donutChart01}
                        loading="lazy"
                        alt=""
                        src="/donut-chart-01.svg"
                      />
                      <div className={styles.widget}>
                        <div className={styles.content16}>
                          <div className={styles.tag4}>
                            <input className={styles.dot2} type="radio" />
                            <div className={styles.tag5}>United States</div>
                          </div>
                          <div className={styles.text70}>
                            <div className={styles.text71}>38.6%</div>
                          </div>
                        </div>
                        <div className={styles.content17}>
                          <div className={styles.tag6}>
                            <input className={styles.dot3} type="radio" />
                            <div className={styles.tag7}>Canada</div>
                          </div>
                          <div className={styles.text72}>
                            <div className={styles.text73}>22.5%</div>
                          </div>
                        </div>
                        <div className={styles.content18}>
                          <div className={styles.tag8}>
                            <input className={styles.dot4} type="radio" />
                            <div className={styles.tag9}>Mexico</div>
                          </div>
                          <div className={styles.text74}>
                            <div className={styles.text75}>30.8%</div>
                          </div>
                        </div>
                        <div className={styles.content19}>
                          <div className={styles.tag10}>
                            <input className={styles.dot5} type="radio" />
                            <div className={styles.tag11}>Other</div>
                          </div>
                          <div className={styles.text76}>
                            <div className={styles.text77}>8.1%</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className={styles.block4}>
                    <div className={styles.text78}>
                      <div className={styles.text79}>{`Marketing & SEO`}</div>
                    </div>
                    <div className={styles.chart2}>
                      <div className={styles.leftText2}>
                        <div className={styles.div16}>30M</div>
                        <div className={styles.div17}>20M</div>
                        <div className={styles.div18}>10M</div>
                        <div className={styles.div19}>0M</div>
                      </div>
                      <div className={styles.frame7}>
                        <div className={styles.line2}>
                          <div className={styles.div20} />
                          <div className={styles.div21} />
                          <div className={styles.div22} />
                          <div className={styles.div23} />
                        </div>
                        <div className={styles.verticalBar1}>
                          <div className={styles.div24}>
                            <div className={styles.rectangle13} />
                          </div>
                          <div className={styles.div25}>
                            <div className={styles.rectangle14} />
                          </div>
                          <div className={styles.div26}>
                            <div className={styles.rectangle15} />
                          </div>
                          <div className={styles.div27}>
                            <div className={styles.rectangle16} />
                          </div>
                          <div className={styles.div28}>
                            <div className={styles.rectangle17} />
                          </div>
                          <div className={styles.div29}>
                            <div className={styles.rectangle18} />
                          </div>
                          <div className={styles.div30}>
                            <div className={styles.rectangle19} />
                          </div>
                          <div className={styles.div31}>
                            <div className={styles.rectangle20} />
                          </div>
                          <div className={styles.div32}>
                            <div className={styles.rectangle21} />
                          </div>
                          <div className={styles.div33}>
                            <div className={styles.rectangle22} />
                          </div>
                          <div className={styles.div34}>
                            <div className={styles.rectangle23} />
                          </div>
                          <div className={styles.div35}>
                            <div className={styles.rectangle24} />
                          </div>
                        </div>
                        <div className={styles.bottomText2}>
                          <div className={styles.div36}>Jan</div>
                          <div className={styles.div37}>Feb</div>
                          <div className={styles.div38}>Mar</div>
                          <div className={styles.div39}>Apr</div>
                          <div className={styles.div40}>May</div>
                          <div className={styles.div41}>Jun</div>
                          <div className={styles.div42}>Jul</div>
                          <div className={styles.div43}>Aug</div>
                          <div className={styles.div44}>Sep</div>
                          <div className={styles.div45}>Oct</div>
                          <div className={styles.div46}>Nov</div>
                          <div className={styles.div47}>Dec</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>
          <RightBar />
        </main>
        <div
          className={styles.decisionMaker}
          onClick={onDecisionMakerContainerClick}
        >
          <img
            className={styles.decisionMakerChild}
            loading="lazy"
            alt=""
            src="/group-1.svg"
          />
          <div className={styles.homeWrapper}>
            <b className={styles.home}>Home</b>
          </div>
        </div>
        <div
          className={styles.decisionMaker1}
          onClick={onDecisionMakerContainer1Click}
        >
          <img
            className={styles.carbonanalyticsIcon}
            loading="lazy"
            alt=""
            src="/carbonanalytics.svg"
          />
          <b className={styles.analytics1}>Analytics</b>
        </div>
        <div
          className={styles.decisionMaker2}
          onClick={onDecisionMakerContainer2Click}
        >
          <img
            className={styles.jamcoinFIcon}
            loading="lazy"
            alt=""
            src="/jamcoinf.svg"
          />
          <b className={styles.payouts}>Payouts</b>
        </div>
        <div
          className={styles.decisionMaker3}
          onClick={onDecisionMakerContainer3Click}
        >
          <img
            className={styles.fluentpeopleCommunity24FilIcon}
            loading="lazy"
            alt=""
            src="/fluentpeoplecommunity24filled.svg"
          />
          <div className={styles.communityWrapper}>
            <b className={styles.community}>Community</b>
          </div>
        </div>
        <img
          className={styles.materialSymbolsdashboardIcon}
          loading="lazy"
          alt=""
          src="/materialsymbolsdashboard.svg"
        />
        <b className={styles.dashboard}>Dashboard</b>
        <div
          className={styles.decisionMaker4}
          onClick={onDecisionMakerContainer4Click}
        >
          <img
            className={styles.gameIconsshadowFollower}
            loading="lazy"
            alt=""
            src="/gameiconsshadowfollower.svg"
          />
          <div className={styles.folllowersWrapper}>
            <b className={styles.folllowers}>Folllowers</b>
          </div>
        </div>
        <div
          className={styles.decisionMaker5}
          onClick={onDecisionMakerContainer5Click}
        >
          <img
            className={styles.arcticonsrewards}
            alt=""
            src="/arcticonsrewards.svg"
          />
          <div className={styles.rewardsWrapper}>
            <b className={styles.rewards}>Rewards</b>
          </div>
        </div>
        <img
          className={styles.uilsettingIcon}
          loading="lazy"
          alt=""
          src="/uilsetting.svg"
        />
        <b className={styles.settings}>Settings</b>
        <img
          className={styles.materialSymbolssupportIcon}
          loading="lazy"
          alt=""
          src="/materialsymbolssupport.svg"
        />
        <b className={styles.support}>Support</b>
        <div className={styles.functionCaller} />
        <div className={styles.userNameParent}>
          <b className={styles.userName} data-scroll-to="userNameText">
            User Name
          </b>
          <img
            className={styles.gridiconsdropdown}
            loading="lazy"
            alt=""
            src="/gridiconsdropdown.svg"
          />
        </div>
        <div
          className={styles.decisionMaker6}
          onClick={onDecisionMakerContainer6Click}
        >
          <img
            className={styles.gridiconsproduct}
            loading="lazy"
            alt=""
            src="/gridiconsproduct.svg"
          />
          <div className={styles.productWrapper}>
            <b className={styles.product}>Product</b>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;
