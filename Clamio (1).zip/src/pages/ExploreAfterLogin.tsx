import { FunctionComponent, useCallback } from "react";
import FrameComponent8 from "../components/FrameComponent8";
import FrameComponent7 from "../components/FrameComponent7";
import { useNavigate } from "react-router-dom";
import FrameComponent6 from "../components/FrameComponent6";
import styles from "./ExploreAfterLogin.module.css";

const ExploreAfterLogin: FunctionComponent = () => {
  const navigate = useNavigate();

  const onFrameButtonClick = useCallback(() => {
    navigate("/creator-login");
  }, [navigate]);

  const onFrameButton1Click = useCallback(() => {
    navigate("/product");
  }, [navigate]);

  return (
    <div className={styles.exploreAfterLogin}>
      <FrameComponent8 />
      <section className={styles.exploreAfterLoginInner}>
        <div className={styles.frameParent}>
          <div className={styles.frameGroup}>
            <div className={styles.frameWrapper}>
              <div className={styles.takeHome100OfYourRevenueParent}>
                <h1 className={styles.takeHome100}>
                  Take home 100% of your Revenue
                </h1>
                <div className={styles.weCharge125OnEachSuccesWrapper}>
                  <h1 className={styles.weCharge125}>
                    We charge 12.5% on each successful transaction
                  </h1>
                </div>
              </div>
            </div>
            <div className={styles.frameContainer}>
              <div className={styles.frameDiv}>
                <div className={styles.frameParent1}>
                  <FrameComponent7
                    you="You"
                    youWillBeCharged125="You will be charged 12.5% "
                    rs100="Rs. 100"
                    rs875="Rs. 87.5"
                  />
                  <FrameComponent7
                    you="Your Customers"
                    youWillBeCharged125="Customers will be charged 12.5% "
                    rs100="Rs. 112.5"
                    rs875="Rs. 100"
                  />
                </div>
              </div>
              <div className={styles.frameWrapper1}>
                <button
                  className={styles.rectangleParent}
                  onClick={onFrameButtonClick}
                >
                  <div className={styles.frameChild} />
                  <b className={styles.startSelling}>START SELLING</b>
                </button>
              </div>
              <div className={styles.frameWrapper2}>
                <div className={styles.frameParent2}>
                  <div className={styles.b4ff0c68d07443f74cb851462d4870Wrapper}>
                    <img
                      className={styles.b4ff0c68d07443f74cb851462d4870Icon}
                      loading="lazy"
                      alt=""
                      src="/b4ff0c68d07443f74cb851462d487042removebgpreview-1@2x.png"
                    />
                  </div>
                  <h1 className={styles.topDigitalProducts}>
                    Top Digital Products
                  </h1>
                </div>
              </div>
              <div className={styles.frameParent3}>
                <div className={styles.frameParent4}>
                  <div className={styles.tarotCardReadingParent}>
                    <h2 className={styles.tarotCardReading}>
                      Tarot Card Reading
                    </h2>
                    <div className={styles.discoverYourPath}>
                      Discover your path with a personalized tarot reading from
                      expert creators on our platform.
                    </div>
                  </div>
                  <div className={styles.frameWrapper3}>
                    <div className={styles.foodRecipesParent}>
                      <h2 className={styles.foodRecipes}>Food Recipes</h2>
                      <div className={styles.elevateYourCulinary}>
                        Elevate your culinary skills with our food recipe
                        creators, offering delectable dishes and expert guidance
                        for your culinary journey
                      </div>
                    </div>
                  </div>
                  <div className={styles.digitalArtParent}>
                    <h2 className={styles.digitalArt}>Digital Art</h2>
                    <div className={styles.immerseYourselfIn}>
                      Immerse yourself in the world of digital artistry with our
                      talented creators, who transform visions into Reality
                    </div>
                  </div>
                </div>
                <div className={styles.frameParent5}>
                  <div className={styles.travelGuideParent}>
                    <h2 className={styles.travelGuide}>Travel Guide</h2>
                    <div className={styles.experienceHiddenAdventures}>
                      Experience hidden adventures through our creators' digital
                      travel guides and stories.
                    </div>
                  </div>
                  <div className={styles.frameWrapper4}>
                    <div className={styles.dietPlanParent}>
                      <h2 className={styles.dietPlan}>Diet Plan</h2>
                      <div className={styles.transformYourHealth}>
                        Transform your health with personalized diet plans
                        crafted by our expert dietitian creators
                      </div>
                    </div>
                  </div>
                  <div className={styles.frameParent6}>
                    <div className={styles.eSportsGuideWrapper}>
                      <h2 className={styles.eSportsGuide}>E-Sports Guide</h2>
                    </div>
                    <div className={styles.levelUpYour}>
                      Level up your esports game with insights and strategies
                      from our gaming experts
                    </div>
                  </div>
                </div>
              </div>
              <div className={styles.frameWrapper5}>
                <button
                  className={styles.browseProductsWrapper}
                  onClick={onFrameButton1Click}
                >
                  <b className={styles.browseProducts}>Browse Products</b>
                </button>
              </div>
            </div>
            <h1 className={styles.faqs}>FAQs</h1>
            <div className={styles.frameParent7}>
              <div className={styles.canIAddWideRangeOfProducParent}>
                <h2 className={styles.canIAdd}>
                  Can I add wide range of products?
                </h2>
                <div className={styles.absolutelyOurPlatform}>
                  Absolutely! Our platform allows you to easily add wide range
                  of products from your catalog.
                </div>
              </div>
              <div className={styles.whatKindOfDigitalProductsParent}>
                <h2 className={styles.whatKindOf}>
                  What kind of digital products can I sell?
                </h2>
                <div className={styles.youCanSell}>
                  You can sell a wide range of digital products like ebooks,
                  software, videos, music, and more.
                </div>
              </div>
            </div>
          </div>
          <FrameComponent6 />
        </div>
      </section>
    </div>
  );
};

export default ExploreAfterLogin;
