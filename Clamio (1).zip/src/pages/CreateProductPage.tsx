import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import FrameComponent12 from "../components/FrameComponent12";
import FrameComponent11 from "../components/FrameComponent11";
import styles from "./CreateProductPage.module.css";

const CreateProductPage: FunctionComponent = () => {
  const navigate = useNavigate();

  const onReferAndEarnClick = useCallback(() => {
    navigate("/rewards");
  }, [navigate]);

  const onCreateProductPageClick = useCallback(() => {
    navigate("/creator-login");
  }, [navigate]);

  const onCreateProductPage1Click = useCallback(() => {
    navigate("/analytics");
  }, [navigate]);

  const onCreateProductPage2Click = useCallback(() => {
    // Please sync "Payouts" to the project
  }, []);

  const onCreateProductPage3Click = useCallback(() => {
    navigate("/usercreator-community");
  }, [navigate]);

  const onCreateProductPage4Click = useCallback(() => {
    // Please sync "Followers" to the project
  }, []);

  const onCreateProductPage5Click = useCallback(() => {
    navigate("/rewards");
  }, [navigate]);

  const onCreateProductPage6Click = useCallback(() => {
    // Please sync " Listing" to the project
  }, []);

  const onCreateProductPage16Click = useCallback(() => {
    navigate("/creator-login");
  }, [navigate]);

  const onCreateProductPage17Click = useCallback(() => {
    navigate("/product-details-and-listing");
  }, [navigate]);

  const onGoToExploreClick = useCallback(() => {
    navigate("/explore-after-login");
  }, [navigate]);

  return (
    <div className={styles.createProductPage}>
      <b className={styles.referAndEarn} onClick={onReferAndEarnClick}>
        Refer and Earn
      </b>
      <div
        className={styles.createProductPage1}
        onClick={onCreateProductPageClick}
      >
        <img
          className={styles.createProductPageChild}
          alt=""
          src="/group-1.svg"
        />
        <div className={styles.homeWrapper}>
          <b className={styles.home}>Home</b>
        </div>
      </div>
      <div
        className={styles.createProductPage2}
        onClick={onCreateProductPage1Click}
      >
        <img
          className={styles.carbonanalyticsIcon}
          loading="lazy"
          alt=""
          src="/carbonanalytics.svg"
        />
        <b className={styles.analytics}>Analytics</b>
      </div>
      <div
        className={styles.createProductPage3}
        onClick={onCreateProductPage2Click}
      >
        <img
          className={styles.jamcoinFIcon}
          loading="lazy"
          alt=""
          src="/jamcoinf.svg"
        />
        <b className={styles.payouts}>Payouts</b>
      </div>
      <div
        className={styles.createProductPage4}
        onClick={onCreateProductPage3Click}
      >
        <img
          className={styles.fluentpeopleCommunity24FilIcon}
          loading="lazy"
          alt=""
          src="/fluentpeoplecommunity24filled.svg"
        />
        <div className={styles.communityWrapper}>
          <b className={styles.community}>Community</b>
        </div>
      </div>
      <b className={styles.dashboard}>Dashboard</b>
      <div
        className={styles.createProductPage5}
        onClick={onCreateProductPage4Click}
      >
        <img
          className={styles.gameIconsshadowFollower}
          loading="lazy"
          alt=""
          src="/gameiconsshadowfollower.svg"
        />
        <div className={styles.folllowersWrapper}>
          <b className={styles.folllowers}>Folllowers</b>
        </div>
      </div>
      <div
        className={styles.createProductPage6}
        onClick={onCreateProductPage5Click}
      >
        <img
          className={styles.arcticonsrewards}
          loading="lazy"
          alt=""
          src="/arcticonsrewards.svg"
        />
        <div className={styles.rewardsWrapper}>
          <b className={styles.rewards}>Rewards</b>
        </div>
      </div>
      <b className={styles.settings}>Settings</b>
      <b className={styles.support}>Support</b>
      <b className={styles.userName}>User Name</b>
      <main className={styles.zondiconsnotificationParent}>
        <img
          className={styles.zondiconsnotification}
          alt=""
          src="/zondiconsnotification.svg"
        />
        <img
          className={styles.materialSymbolsdashboardIcon}
          loading="lazy"
          alt=""
          src="/materialsymbolsdashboard.svg"
        />
        <img
          className={styles.uilsettingIcon}
          loading="lazy"
          alt=""
          src="/uilsetting.svg"
        />
        <img
          className={styles.materialSymbolssupportIcon}
          loading="lazy"
          alt=""
          src="/materialsymbolssupport.svg"
        />
        <img
          className={styles.frameChild}
          loading="lazy"
          alt=""
          src="/vector-711.svg"
        />
        <img className={styles.frameItem} alt="" src="/vector-88.svg" />
        <div className={styles.frameInner} />
        <img
          className={styles.gridiconsdropdown}
          loading="lazy"
          alt=""
          src="/gridiconsdropdown.svg"
        />
      </main>
      <div
        className={styles.createProductPage7}
        onClick={onCreateProductPage6Click}
      >
        <img
          className={styles.gridiconsproduct}
          loading="lazy"
          alt=""
          src="/gridiconsproduct.svg"
        />
        <div className={styles.productWrapper}>
          <b className={styles.product}>Product</b>
        </div>
      </div>
      <FrameComponent12 />
      <h2 className={styles.inputProductName}>Input Product name</h2>
      <h2 className={styles.inputProductDescription}>
        Input Product Description
      </h2>
      <h2 className={styles.inputProductImagevideo}>
        Input Product Image/Video
      </h2>
      <button className={styles.rectangleParent}>
        <div className={styles.rectangleDiv} />
        <b className={styles.inputArea}>input area</b>
      </button>
      <textarea
        className={styles.createSomethingNewButton}
        placeholder="input area"
        rows={20}
        cols={26}
      />
      <div className={styles.rectangleGroup}>
        <div className={styles.frameChild1} />
        <button className={styles.featureInputArea}>
          <div className={styles.featureInputAreaChild} />
          <img className={styles.vectorIcon} alt="" src="/vector41.svg" />
        </button>
      </div>
      <div className={styles.createProductPage8}>
        <div className={styles.createProductPageItem} />
        <div className={styles.rectangleContainer}>
          <div className={styles.frameChild2} />
          <img className={styles.vectorIcon1} alt="" src="/vector-122.svg" />
        </div>
      </div>
      <div className={styles.createProductPage9}>
        <div className={styles.createProductPageInner} />
        <div className={styles.frameDiv}>
          <div className={styles.frameChild3} />
          <img className={styles.vectorIcon2} alt="" src="/vector-122.svg" />
        </div>
      </div>
      <div className={styles.createProductPage10}>
        <div className={styles.createProductPageChild1} />
        <div className={styles.rectangleParent1}>
          <div className={styles.frameChild4} />
          <img className={styles.vectorIcon3} alt="" src="/vector-122.svg" />
        </div>
      </div>
      <h2 className={styles.setPrice}>Set Price</h2>
      <div className={styles.createProductPageInner1}>
        <div className={styles.rectangleParent2}>
          <div className={styles.frameChild5} />
          <img className={styles.mdirupeeIcon} alt="" src="/mdirupee.svg" />
        </div>
      </div>
      <h1 className={styles.createSomethingNew}>Create something new</h1>
      <h2 className={styles.inputProductCategory}>Input Product Category</h2>
      <FrameComponent11 />
      <FrameComponent11 propTop="1235px" propLeft="347px" />
      <FrameComponent11 propTop="984px" propLeft="700px" />
      <FrameComponent11 propTop="1235px" propLeft="700px" />
      <FrameComponent11 propTop="982px" propLeft="1053px" />
      <FrameComponent11 propTop="1233px" propLeft="1053px" />
      <button
        className={styles.createProductPage11}
        onClick={onCreateProductPage16Click}
      >
        <div className={styles.createProductPageChild2} />
        <b className={styles.cancel}>Cancel</b>
      </button>
      <button
        className={styles.createProductPage12}
        onClick={onCreateProductPage17Click}
      >
        <div className={styles.rectangleParent3}>
          <div className={styles.frameChild6} />
          <b className={styles.launchProduct}>Launch Product</b>
        </div>
      </button>
      <b
        className={styles.goToExplore}
        onClick={onGoToExploreClick}
      >{`Go to Explore `}</b>
    </div>
  );
};

export default CreateProductPage;
