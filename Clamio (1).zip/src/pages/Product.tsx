import { FunctionComponent } from "react";
import FrameComponent20 from "../components/FrameComponent20";
import FrameComponent19 from "../components/FrameComponent19";
import ParentWithChildrenStar from "../components/ParentWithChildrenStar";
import styles from "./Product.module.css";

const Product: FunctionComponent = () => {
  return (
    <div className={styles.product}>
      <FrameComponent20 />
      <FrameComponent19 />
      <section className={styles.productInner}>
        <div className={styles.frameParent}>
          <div className={styles.topSellingProductParent}>
            <h1 className={styles.topSellingProduct}>Top Selling Product</h1>
            <button className={styles.rectangleParent}>
              <div className={styles.frameChild} />
              <b className={styles.viewAll}>View All</b>
            </button>
          </div>
          <div className={styles.frameGroup}>
            <ParentWithChildrenStar
              propAlignSelf="unset"
              propWidth="unset"
              propFlex="1"
              propMinWidth="264px"
              propFlex1="unset"
              propHeight="265px"
            />
            <ParentWithChildrenStar
              propAlignSelf="unset"
              propWidth="unset"
              propFlex="1"
              propMinWidth="264px"
              propFlex1="unset"
              propHeight="265px"
            />
            <ParentWithChildrenStar
              propAlignSelf="unset"
              propWidth="unset"
              propFlex="1"
              propMinWidth="264px"
              propFlex1="unset"
              propHeight="265px"
            />
            <ParentWithChildrenStar
              propAlignSelf="unset"
              propWidth="unset"
              propFlex="1"
              propMinWidth="264px"
              propFlex1="unset"
              propHeight="265px"
            />
          </div>
        </div>
      </section>
      <section className={styles.productChild}>
        <div className={styles.frameContainer}>
          <div className={styles.hotAndNewProductParent}>
            <h1 className={styles.hotAndNew}>Hot And New Product</h1>
            <button className={styles.rectangleGroup}>
              <div className={styles.frameItem} />
              <b className={styles.viewAll1}>View All</b>
            </button>
          </div>
          <div className={styles.frameDiv}>
            <ParentWithChildrenStar
              propAlignSelf="unset"
              propWidth="unset"
              propFlex="1"
              propMinWidth="264px"
              propFlex1="unset"
              propHeight="265px"
            />
            <ParentWithChildrenStar
              propAlignSelf="unset"
              propWidth="unset"
              propFlex="1"
              propMinWidth="264px"
              propFlex1="unset"
              propHeight="265px"
            />
            <ParentWithChildrenStar
              propAlignSelf="unset"
              propWidth="unset"
              propFlex="1"
              propMinWidth="264px"
              propFlex1="unset"
              propHeight="265px"
            />
            <ParentWithChildrenStar
              propAlignSelf="unset"
              propWidth="unset"
              propFlex="1"
              propMinWidth="264px"
              propFlex1="unset"
              propHeight="265px"
            />
          </div>
        </div>
      </section>
      <section className={styles.frameSection}>
        <div className={styles.frameParent1}>
          <div className={styles.topSellingProductGroup}>
            <h1 className={styles.topSellingProduct1}>Top Selling Product</h1>
            <button className={styles.rectangleContainer}>
              <div className={styles.frameInner} />
              <b className={styles.viewAll2}>View All</b>
            </button>
          </div>
          <div className={styles.frameParent2}>
            <ParentWithChildrenStar
              propAlignSelf="unset"
              propWidth="unset"
              propFlex="1"
              propMinWidth="264px"
              propFlex1="unset"
              propHeight="265px"
            />
            <ParentWithChildrenStar
              propAlignSelf="unset"
              propWidth="unset"
              propFlex="1"
              propMinWidth="264px"
              propFlex1="unset"
              propHeight="265px"
            />
            <ParentWithChildrenStar
              propAlignSelf="unset"
              propWidth="unset"
              propFlex="1"
              propMinWidth="264px"
              propFlex1="unset"
              propHeight="265px"
            />
            <ParentWithChildrenStar
              propAlignSelf="unset"
              propWidth="unset"
              propFlex="1"
              propMinWidth="264px"
              propFlex1="unset"
              propHeight="265px"
            />
          </div>
        </div>
      </section>
    </div>
  );
};

export default Product;
