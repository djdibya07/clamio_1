import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import FrameComponent24 from "../components/FrameComponent24";
import FrameComponent22 from "../components/FrameComponent22";
import FrameComponent21 from "../components/FrameComponent21";
import styles from "./UserCreatorCommunity.module.css";

const UserCreatorCommunity: FunctionComponent = () => {
  const navigate = useNavigate();

  const onFindMyCommunityClick = useCallback(() => {
    navigate("/creator-login");
  }, [navigate]);

  const onCOMMUNIITYTextClick = useCallback(() => {
    navigate("/usercreator-community");
  }, [navigate]);

  const onExploreTextClick = useCallback(() => {
    navigate("/product");
  }, [navigate]);

  const onCreatorsTextClick = useCallback(() => {
    // Please sync "Discover Creator" to the project
  }, []);

  const onJoinTextClick = useCallback(() => {
    // Please sync "login and sign up" to the project
  }, []);

  return (
    <div className={styles.usercreatorCommunity}>
      <section className={styles.rectangleParent}>
        <div className={styles.frameChild} />
        <div className={styles.frameWrapper}>
          <div className={styles.frameParent}>
            <div className={styles.findMyCommunityWrapper}>
              <div
                className={styles.findMyCommunity}
                onClick={onFindMyCommunityClick}
              >
                <img
                  className={styles.findMyCommunityChild}
                  loading="lazy"
                  alt=""
                  src="/group-11.svg"
                />
                <div className={styles.createAndSellWrapper}>
                  <b className={styles.createAndSell}>Create and Sell</b>
                </div>
              </div>
            </div>
            <nav className={styles.frameGroup}>
              <div className={styles.communiityWrapper}>
                <b
                  className={styles.communiity}
                  onClick={onCOMMUNIITYTextClick}
                >
                  COMMUNIITY
                </b>
              </div>
              <b className={styles.explore} onClick={onExploreTextClick}>
                Explore
              </b>
              <div className={styles.creatorsWrapper}>
                <b className={styles.creators} onClick={onCreatorsTextClick}>
                  Creators
                </b>
              </div>
              <b className={styles.join} onClick={onJoinTextClick}>
                Join
              </b>
            </nav>
          </div>
        </div>
        <FrameComponent24 />
      </section>
      <FrameComponent22 />
      <FrameComponent21 />
    </div>
  );
};

export default UserCreatorCommunity;
